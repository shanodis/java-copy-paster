package com.dg_mw;

import com.dg_mw.dtos.CalculatorOperationResponse;
import com.dg_mw.services.CalculatorOperationService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;


@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class CalculatorServiceTests {
    @Autowired
    CalculatorOperationService calculator;

    @Test
    public void test_add() {
        // when
        List<Float> numbers = Arrays.asList(2f, 3f, 4f);
        CalculatorOperationResponse<Float> response = calculator.add(numbers);
        // then
        assertEquals(9f, response.getResult(),0.001f);
    }

    @Test
    public void test_subtract() {
        // when
        List<Float> numbers = new ArrayList<>(Arrays.asList(10f, 2f, 3f));
        CalculatorOperationResponse<Float> response = calculator.subtract(numbers);
        // then
        assertEquals(5f, response.getResult(),0.001f);
    }

    @Test
    public void test_multiply() {
        // when
        List<Float> numbers = Arrays.asList(2f, 3f, 4f);
        CalculatorOperationResponse<Float> response = calculator.multiply(numbers);
        // then
        assertEquals(24f, response.getResult(),0.001f);
    }

    @Test
    public void test_divide() {
        // when
        List<Float> numbers = new ArrayList<>(Arrays.asList(10f, 2f, 5f));
        CalculatorOperationResponse<Float> response = calculator.divide(numbers);
        // then
        assertEquals(1f, response.getResult(),0.001f);
    }

    @Test
    public void test_fib() {
        // when
        Integer count = 5;
        CalculatorOperationResponse<Integer> response = calculator.fib(count);
        // then
        assertEquals(7, response.getResult().intValue());
    }

    @Test
    public void test_divideShouldThrowException() {
        List<Float> numbers = Arrays.asList(10f, 0f, 5f);
        // then
        ResponseStatusException exception = assertThrows(ResponseStatusException.class, () -> calculator.divide(numbers));
        assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        assertEquals("Can't divide by 0!", exception.getReason());
    }

    @Test
    public void testFibWithCountLessThanOne() {
        assertThrows(IllegalArgumentException.class, () -> calculator.fib(-1));
    }
}
