package com.dg_mw.services;

import com.dg_mw.dtos.CalculatorOperationResponse;

import java.util.List;

public interface ICalculatorOperationService {
    CalculatorOperationResponse<Float> add(List<Float> numbers);
    CalculatorOperationResponse<Float> subtract(List<Float> numbers);
    CalculatorOperationResponse<Float> multiply(List<Float> numbers);
    CalculatorOperationResponse<Float> divide(List<Float> numbers);
    CalculatorOperationResponse<Integer> fib(Integer count);
}
