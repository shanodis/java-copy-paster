import CONSTANTS from "./constants.js";

export function generateHealthEmoji(health) {
    const container = $('#healthContainer');
    container.html('');
    if (health >= 20) {
        health = 20;
    }
    const fullHearts = Math.floor(health / 2);
    const halfHeart = health % 2 === 1;
    const emptyHearts = 10 - fullHearts - (halfHeart ? 1 : 0);
    container.html(CONSTANTS.EMOJI_HEART_FULL.repeat(fullHearts) + (halfHeart ? CONSTANTS.EMOJI_HEART_HALF : '') + CONSTANTS.EMOJI_HEART_EMPTY.repeat(emptyHearts));
}

export function generateFoodLevelEmoji(foodLevel) {
    const foodLevelContainer = $('#foodLevelContainer');
    foodLevelContainer.html('');
    if (foodLevel >= 20) {
        foodLevel = 20;
    }
    const fullDrumsticks = Math.min(Math.floor(foodLevel / 2), 10);
    const halfDrumstick = foodLevel % 2 === 1;
    const emptyPlates = 10 - fullDrumsticks - (halfDrumstick ? 1 : 0);
    foodLevelContainer.html(CONSTANTS.EMOJI_FOOD_FULL.repeat(fullDrumsticks) + (halfDrumstick ? CONSTANTS.EMOJI_FOOD_HALF : '') + CONSTANTS.EMOJI_FOOD_EMPTY.repeat(emptyPlates));
}