import CONSTANTS, {mapGameObject, mapTileType} from "./constants.js";

let gameWorld = null;
export function renderWorld(gameWorld) {
    const worldTable = $('#worldTable');
    worldTable.empty();

    if (gameWorld) {
        const gameTiles = gameWorld.gameTiles;
        const numRows = gameTiles.length;
        const numCols = gameTiles[0].length;

        for (let i = 0; i < numRows; i++) {
            const row = $('<tr></tr>');
            for (let j = 0; j < numCols; j++) {
                const gameTile = gameTiles[i][j][0];
                const tileType = mapTileType(gameTile.tileType);
                const gameObject = gameTile.gameObject ? mapGameObject(gameTile.gameObject.objectType) : '';

                const cell = $('<td></td>');
                const tileSpan = $('<span class="tile">' + tileType + '</span>');
                const objectSpan = $('<span class="object">' + gameObject + '</span>');

                cell.append(tileSpan);
                cell.append(objectSpan);

                if (i === Math.floor(CONSTANTS.TILE_SIZE / 2) && j === Math.floor(CONSTANTS.TILE_SIZE / 2)) {
                    cell.addClass('player-cell');
                    cell.css('background-color', 'red');
                    cell.text(CONSTANTS.EMOJI_PLAYER);
                }

                row.append(cell);
            }

            worldTable.append(row);
        }
    }
}

export function getWorldData() {
    return gameWorld;
}
export function setWorldData(data) {
    gameWorld = data;
}