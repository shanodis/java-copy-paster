const CONSTANTS = {
    TILE_SIZE: 16,
    EMOJI_HEART_FULL: "❤️",
    EMOJI_HEART_HALF: "❤️‍🩹",
    EMOJI_HEART_EMPTY: "🤎",
    EMOJI_FOOD_FULL: "🍗",
    EMOJI_FOOD_HALF: "🍽️",
    EMOJI_FOOD_EMPTY: "🍽️",
    EMOJI_PLAYER: "🤖️",
};

export default CONSTANTS;


export function getItemCategory(itemType) {
    switch (itemType) {
        case 'FOOD':
            return 'Food';
        case 'CLOTHING':
            return 'Clothing';
        case 'ITEMS':
            return 'Items';
        case 'TOOLS':
            return 'Tools';
        case 'BOOKS':
            return 'Books';
        case 'ELECTRONICS':
            return 'Electronics';
        default:
            return 'Other';
    }
}

export function mapTileType(tileType) {
    switch (tileType) {
        case 'MOUNTAIN':
            return '⛰';
        case 'VOLCANO':
            return '🌋';
        case 'DESERT':
            return '🏜';
        case 'BEACH':
            return '🏖';
        case 'WATER':
            return '🌊';
        case 'ROAD':
            return '🌫';
        case 'EARTH':
            return '🏞';
        case 'GRASS':
            return '🏞';
        case 'SAND':
            return '🏜️';
        case 'LAVA':
            return '🌋';
        default:
            return '';
    }
}

export function mapGameObject(objectType) {
    switch (objectType) {
        case 'TREE':
            return '🌲';
        case 'CACTUS':
            return '🌵';
        case 'CHEST':
            return '📦';
        case 'FLOWER':
            return '🌼';
        case 'PLAYER':
            return '🕵️';
        case 'HOUSE':
            return '🏘';
        case 'ABANDONED_HOUSE':
            return '🏚';
        case 'MODERN_HOUSE':
            return '🏢';
        case 'MODERN_HOUSE_2':
            return '🏬';
        case 'HOSPITAL':
            return '🏥';
        case 'FACTORY':
            return '🏭';
        case 'SHOP':
            return '🏪';
        case 'COUNTRY_HOUSE':
            return '🛖';
        case 'DANGEROUS_PLACE':
            return '♨';
        case 'BANK':
            return '🏦';
        case 'HOTEL':
            return '🏨';
        case 'WOOD':
            return '🪵';
        case 'ROCK':
            return '🪨';
        case 'UNKNOWN':
            return '❓';
        default:
            return '❓';
    }
}

export class PlayerData {
    constructor(builder) {
        this.playerName = builder.playerName;
        this.playerDisplayName = builder.playerDisplayName;
        this.playerUUID = builder.playerUUID;
        this.health = builder.health;
        this.foodLevel = builder.foodLevel;
        this.location = builder.location;
        this.money = builder.money;
        this.inventory = builder.inventory;
        this.stats = builder.stats;
    }
}

export class PlayerDataBuilder {
    constructor() {
        this.playerName = '';
        this.playerDisplayName = '';
        this.playerUUID = '';
        this.health = 0;
        this.foodLevel = 0;
        this.location = [0, 0, 0];
        this.money = 0;
        this.inventory = [];
        this.stats = null;
    }

    withPlayerName(playerName) {
        this.playerName = playerName;
        return this;
    }

    withPlayerDisplayName(playerDisplayName) {
        this.playerDisplayName = playerDisplayName;
        return this;
    }

    withPlayerUUID(playerUUID) {
        this.playerUUID = playerUUID;
        return this;
    }

    withHealth(health) {
        this.health = health;
        return this;
    }

    withFoodLevel(foodLevel) {
        this.foodLevel = foodLevel;
        return this;
    }

    withLocation(location) {
        this.location = location;
        return this;
    }

    withMoney(money) {
        this.money = money;
        return this;
    }

    withInventory(inventory) {
        this.inventory = inventory;
        return this;
    }

    withStats(stats) {
        this.stats = stats;
        return this;
    }

    build() {
        return new PlayerData(this);
    }
}

export class Stats {
    constructor(builder) {
        this.strength = builder.strength;
        this.defense = builder.defense;
        this.agility = builder.agility;
        this.intelligence = builder.intelligence;
        this.charisma = builder.charisma;
        this.luck = builder.luck;
    }
}

export class StatsBuilder {
    constructor() {
        this.strength = 0;
        this.defense = 0;
        this.agility = 0;
        this.intelligence = 0;
        this.charisma = 0;
        this.luck = 0;
    }

    withStrength(strength) {
        this.strength = strength;
        return this;
    }

    withDefense(defense) {
        this.defense = defense;
        return this;
    }

    withAgility(agility) {
        this.agility = agility;
        return this;
    }

    withIntelligence(intelligence) {
        this.intelligence = intelligence;
        return this;
    }

    withCharisma(charisma) {
        this.charisma = charisma;
        return this;
    }

    withLuck(luck) {
        this.luck = luck;
        return this;
    }

    build() {
        return new Stats(this);
    }
}