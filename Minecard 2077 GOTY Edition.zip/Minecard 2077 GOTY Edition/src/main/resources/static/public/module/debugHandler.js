import {getPlayerData, getPlayerDataValue, movePlayer} from "./player.js";
import {generateFoodLevelEmoji, generateHealthEmoji} from "./generateEmoji.js";
import {renderInventory} from "./inventory.js";
import {getWorldData} from "./world.js";

let playerData = null;


export function teleportPlayer(x, y, z = 0) {
    const worldSize = getWorldData().height;
    const minValidX = 8;
    const minValidY = 8;
    const maxValidX = worldSize - 9;
    const maxValidY = worldSize - 9;
    if (x < minValidX || x > maxValidX || y < minValidY || y > maxValidY) {
        alert('Podane współrzędne są nieprawidłowe!');
        return;
    }

    movePlayer(x, y, z);
}

export function changeHealth(newHealth) {
    playerData = getPlayerDataValue();
    playerData.health = newHealth;
    generateHealthEmoji(newHealth);
    axios
        .put('/api/player', playerData)
        .then(function (response) {
            getPlayerData();
        })
        .then(function () {
           // TODO: umieścić logikę, która zostanie wykonana po odświeżeniu danych gracza.
        });
}


export function changeFoodLevel(newFoodLevel) {
    playerData = getPlayerDataValue();
    playerData.foodLevel = newFoodLevel;
    generateFoodLevelEmoji(newFoodLevel);
    axios
        .put('/api/player', playerData)
        .then(function (response) {
            getPlayerData();
        })
        .then(function () {
            // TODO: umieścić logikę, która zostanie wykonana po odświeżeniu danych gracza.
        });
}

export function addItemToInventory(itemName, itemCategory) {
    const itemId = $('#itemIdInput').val();
    const itemType = $('#itemTypeSelect').val();
    const canBeEquipped = $('#canBeEquippedInput').val() === 'true';
    const quantity = parseInt($('#quantityInput').val());

    const itemData = {
        id: itemId,
        name: itemName,
        itemType: itemType,
        itemCategory: itemCategory,
        currentlyEquipped: false,
        canBeEquipped: canBeEquipped,
        quantity: quantity,
    };

    axios
        .post('/api/player/inventory/add', itemData)
        .then(function (response) {
            renderInventory();
            getPlayerData();
        })
        .catch(function (error) {
            console.error(error);
        });
}

export function removeItemFromInventory(itemId) {
    axios
        .delete('/api/player/inventory/' + itemId)
        .then(function (response) {
            renderInventory();
            getPlayerData();
        })
        .catch(function (error) {
            console.error(error);
        });
}