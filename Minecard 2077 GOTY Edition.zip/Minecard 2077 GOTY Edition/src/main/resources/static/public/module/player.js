import { renderStats } from './stats.js';
import {generateFoodLevelEmoji, generateHealthEmoji} from "./generateEmoji.js";
import CONSTANTS from "./constants.js";
import {getWorldData, renderWorld, setWorldData} from "./world.js";

let playerData = null;
let worldSize = null;
export function getPlayerData() {
    return axios
        .get('/api/player')
        .then(function (response) {
            playerData = response.data;
            generateHealthEmoji(response.data.health);
            generateFoodLevelEmoji(response.data.foodLevel);
            renderStats(playerData.stats);
        })
        .catch(function (error) {
            console.error(error);
        });
}

export function getPlayerDataValue() {
    return playerData;
}

export function setPlayerDataValue(newPlayerData) {
    playerData = newPlayerData;
}


export function movePlayer(newX, newY) {
    worldSize= getWorldData().height;
    const playerZ = playerData.location[2];
    const minValidX = 8;
    const minValidY = 8;
    const maxValidX = worldSize - (newY < worldSize / 2 ? 8 : 9);
    const maxValidY = worldSize - (newY < worldSize / 2 ? 8 : 9);
    const updatedX = Math.max(minValidX, Math.min(newX, maxValidX));
    const updatedY = Math.max(minValidY, Math.min(newY, maxValidY));
    playerData.location = [updatedX, updatedY, playerZ];
    const startX = updatedX - Math.floor(CONSTANTS.TILE_SIZE / 2);
    const startY = updatedY - Math.floor(CONSTANTS.TILE_SIZE / 2);

    axios
        .get('/api/world', {
            params: {
                startX: startX, startY: startY, size: CONSTANTS.TILE_SIZE,
            },
        })
        .then(function (response) {
            renderWorld(response.data);
        })
        .catch(function (error) {
            console.error(error);
        });

    playerData.location = [updatedX, updatedY, playerZ];
    axios
        .put('/api/player', playerData)
        .then(function (response) {
            getPlayerData();
        })
        .then(function () {
            // TODO: umieścić logikę, która zostanie wykonana po odświeżeniu danych gracza.
        })
        .catch(function (error) {
            console.error(error);
        });
}