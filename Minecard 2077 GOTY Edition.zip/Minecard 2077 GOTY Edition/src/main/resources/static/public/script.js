import CONSTANTS from './module/constants.js';

import {getPlayerData, getPlayerDataValue, movePlayer, setPlayerDataValue} from './module/player.js';
import {
    addItemToInventory,
    changeFoodLevel,
    changeHealth,
    removeItemFromInventory,
    teleportPlayer
} from "./module/debugHandler.js";
import {renderWorld, setWorldData} from "./module/world.js";
import {renderInventory} from "./module/inventory.js";

$(document).ready(function () {

    const teleportBtn = $('#teleportBtn');
    const healthRange = $('#healthRange');
    const foodLevelRange = $('#foodLevelRange');
    const addItemForm = $('#addItemForm');
    const removeItemForm = $('#removeItemForm');

    $(document).keydown(movePlayerByKeyEvent);

    $('#loadInventoryBtn').on('click', () => openModal('#inventoryModal', renderInventory));
    $('#debugBtn').on('click', () => openModal('#debugModal'));

    teleportBtn.on('click', teleportPlayerByFormInputs);
    healthRange.on('input', () => updatePlayerHealth(healthRange.val()));
    foodLevelRange.on('input', () => updatePlayerFoodLevel(foodLevelRange.val()));
    addItemForm.on('submit', addItemToInventoryByFormInputs);
    removeItemForm.on('submit', removeItemFromInventoryByFormInputs);

    function openModal(modalId, beforeOpen = null) {
        if (beforeOpen) beforeOpen();
        $(modalId).modal('show');
    }

    $("#joinGameForm").submit(function (e) {
        e.preventDefault();
        let playerName = $('#playerName').val();
        if (playerName) {
            loadData(playerName);
            document.getElementById("playerNameDisplay").innerHTML = document.getElementById("playerName").value;
            $("#gameContent").removeClass("d-none");
            $('#joinGameForm').remove();
        }

    });

    function teleportPlayerByFormInputs() {
        const x = parseInt($('#playerXInput').val());
        const y = parseInt($('#playerYInput').val());
        const z = parseInt($('#playerZInput').val() || 0);
        teleportPlayer(x, y, z);
    }

    function updatePlayerHealth(newHealth) {
        changeHealth(parseInt(newHealth));
    }

    function updatePlayerFoodLevel(newFoodLevel) {
        changeFoodLevel(parseInt(newFoodLevel));
    }

    function addItemToInventoryByFormInputs(event) {
        event.preventDefault();
        const itemName = $('#itemNameInput').val();
        const itemCategory = $('#itemCategorySelect').val();
        addItemToInventory(itemName, itemCategory);
    }

    function removeItemFromInventoryByFormInputs(event) {
        event.preventDefault();
        const itemId = $('#itemIdInput').val();
        removeItemFromInventory(itemId);
    }

    function movePlayerByKeyEvent(e) {
        const playerData = getPlayerDataValue();
        const playerX = playerData.location[0];
        const playerY = playerData.location[1];
        const directions = {37: [-1, 0], 38: [0, -1], 39: [1, 0], 40: [0, 1]};
        if (!(e.which in directions)) return;
        const [dx, dy] = directions[e.which];
        movePlayer(playerX + dx, playerY + dy);
    }


    function loadData(playerName) {
        const playerDisplayName = playerName; // Przykładowa wartość playerDisplayName

        axios
            .all([axios.post('/api/world'), axios.post('/api/player', null, {
                params: {
                    playerName: playerName, playerDisplayName: playerDisplayName
                }
            })])
            .then(axios.spread((worldResponse, playerResponse) => {
                getPlayerData().then(() => {
                    const playerData = getPlayerDataValue();
                    alert('Świat został załadowany.');
                    loadWorldData(playerData.location[0], playerData.location[1]);
                });
            }))
            .catch(console.error);
    }

    function loadWorldData(playerX, playerY) {
        const params = {
            startX: playerX - Math.floor(CONSTANTS.TILE_SIZE / 2),
            startY: playerY - Math.floor(CONSTANTS.TILE_SIZE / 2),
            size: CONSTANTS.TILE_SIZE,
        };

        axios
            .get('/api/world', {params})
            .then((response) => {
                setWorldData(response.data);
                renderWorld(response.data);
            })
            .catch(console.error);
    }
});
