package pl.mlodawski.minecard.util.Item.strategy;

import pl.mlodawski.minecard.model.player.PlayerData;
import pl.mlodawski.minecard.util.Item.UseStrategy;

/**
 * The type Disk use strategy.
 */
public class DiskUseStrategy implements UseStrategy {


    @Override
    public void use(PlayerData player) {

    }

    @Override
    public void revert(PlayerData player) {

    }
}
