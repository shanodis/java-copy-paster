package pl.mlodawski.minecard.service.world;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pl.mlodawski.minecard.model.world.GameTile;
import pl.mlodawski.minecard.model.world.GameWorld;
import pl.mlodawski.minecard.util.worldgenerator.module.CityGeneratorModule;
import pl.mlodawski.minecard.util.worldgenerator.StructureModule;
import pl.mlodawski.minecard.util.worldgenerator.module.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * The type Generate world service.
 */
@Service
public class GenerateWorldService {

    @Autowired
    private ObjectMapper objectMapper;

    /**
     * Generate world.
     *
     * @param width  the width
     * @param height the height
     */
    @SneakyThrows
    public void generateWorld(Integer width, Integer height) {
        int structureSize = 3;
        int maxRange = 5;

        StructureModule customStructureModule = loadCustomStructures( structureSize, maxRange);

        WorldGenerator worldGenerator = new WorldGenerator(width, height);
        worldGenerator.addTerrainModule(new ModuleBaseTerrainModule());
        worldGenerator.addTerrainModule(new ModuleDesertGeneratorModule());
        worldGenerator.addTerrainModule(new ModuleOceanGeneratorModule());
        worldGenerator.addTerrainModule(new RiverGeneratorModule());
        worldGenerator.addStructureModule(new CityGeneratorModule());
        worldGenerator.addStructureModule(customStructureModule);
        GameWorld gameWorld = worldGenerator.generate();
        ObjectMapper objectMapper = new ObjectMapper();

        try {
            String json = objectMapper.writeValueAsString(gameWorld);
            saveJsonToFile(json);
         } catch (JsonProcessingException e) {
           System.err.println("Error converting game world to JSON: " + e.getMessage());
        }
    }
    private static class GameTilesWrapper {
        private GameTile[][][] gameTiles;

        /**
         * Instantiates a new Game tiles wrapper.
         *
         * @param gameTiles the game tiles
         */
        public GameTilesWrapper(GameTile[][][] gameTiles) {
            this.gameTiles = gameTiles;
        }

        /**
         * Get game tiles game tile [ ] [ ] [ ].
         *
         * @return the game tile [ ] [ ] [ ]
         */
        public GameTile[][][] getGameTiles() {
            return gameTiles;
        }

        /**
         * Sets game tiles.
         *
         * @param gameTiles the game tiles
         */
        public void setGameTiles(GameTile[][][] gameTiles) {
            this.gameTiles = gameTiles;
        }
    }

    private void saveJsonToFile(String json) {
        final Path path = Paths.get(System.getProperty("user.dir"), "gameWorld.json");
        try (FileWriter fileWriter = new FileWriter(path.toFile())) {
            fileWriter.write(json);
        } catch (IOException e) {
            System.err.println("Error saving JSON to file: " + e.getMessage());
        }
    }

    private String getAppDirectoryPath() {
        try {
            File appDirectory = new File(".");
            return appDirectory.getCanonicalPath();
        } catch (IOException e) {
           System.err.println("Error getting app directory path: " + e.getMessage());
        }
        return null;
    }

    private StructureModule loadCustomStructures(int structureSize, int maxRange) throws IOException {
        final Path path = Paths.get(System.getProperty("user.dir"), "structures.json");
        File file = new File(path.toUri());
        if (!file.exists()) {
            throw new IllegalArgumentException("File " + path + " does not exist.");
        }
        try {
            GameTile[][][] structures = objectMapper.readValue(file, GameTile[][][].class);
            return new CustomStructureModule(structures, structureSize, maxRange);
        } catch (IOException e) {
            throw new IOException("Error reading custom structures from file.", e);
        }
    }
}
