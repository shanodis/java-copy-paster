package pl.mlodawski.minecard.model.user;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * The type RegisterUser dto.
 */
@Data
@AllArgsConstructor
public class ChangeUserPasswordDTO {
    @NotBlank
    @Size(max = 20, message = "Password should be shorter")
    private String oldPassword;
    @NotBlank
    @Size(max = 20, message = "Password should be shorter")
    private String newPassword;
}