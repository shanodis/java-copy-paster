package pl.mlodawski.minecard.util.Item.strategy;

import pl.mlodawski.minecard.model.player.PlayerData;
import pl.mlodawski.minecard.util.Item.UseStrategy;

/**
 * The type Electronics use strategy.
 */
public class ElectronicsUseStrategy implements UseStrategy {


    @Override
    public void use(PlayerData player) {
      player.getStats().setIntelligence(player.getStats().getIntelligence() + 1);
    }

    @Override
    public void revert(PlayerData player) {
        player.getStats().setIntelligence(player.getStats().getIntelligence() - 1);
    }
}