package pl.mlodawski.minecard.controller.player;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pl.mlodawski.minecard.controller.world.GameController;
import pl.mlodawski.minecard.model.world.GameTile;
import pl.mlodawski.minecard.model.world.GameWorld;
import pl.mlodawski.minecard.model.player.PlayerData;
import pl.mlodawski.minecard.model.player.Stats;
import pl.mlodawski.minecard.service.player.PlayerService;
import pl.mlodawski.minecard.service.world.WorldService;
import pl.mlodawski.minecard.util.player.PlayerSerializer;
import pl.mlodawski.minecard.util.player.GameEvent;

import java.io.IOException;
import java.util.UUID;

/**
 * The type Player controller.
 */
@Tag(name = "Player", description = "The player API")
@RestController
public class PlayerController {

    @Autowired
    private GameController gameController;

    @Autowired
    private PlayerSerializer playerSerializer;

    @Autowired
    private PlayerService playerService;

    @Autowired
    private WorldService worldService;


    /**
     * Update player data response entity.
     *
     * @param updatedPlayerData the updated player data
     * @return the response entity
     * @throws IOException the io exception
     */

    @Operation(summary = "Update player data",
            description = "This method updates the player's location and data based on the provided input.",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successful operation"),
                    @ApiResponse(responseCode = "500", description = "Internal server error occurred"),
                    @ApiResponse(responseCode = "202", description = "Accepted but not completed operation")
            })
    @PutMapping("/api/player")
    public ResponseEntity<String> updatePlayerData(@io.swagger.v3.oas.annotations.parameters.RequestBody(description = "The player data to be updated", required = true,
            content = @Content(schema = @Schema(implementation = PlayerData.class))) @RequestBody PlayerData updatedPlayerData) throws IOException {
        GameWorld world = worldService.getWorld();
        int worldSizeX = world.getWidth();
        int worldSizeY = world.getHeight();
        int updatedX = Math.max(0, Math.min(updatedPlayerData.getLocation()[0], worldSizeX - 1));
        int updatedY = Math.max(0, Math.min(updatedPlayerData.getLocation()[1], worldSizeY - 1));
        playerService.updatePlayerData(updatedX, updatedY, updatedPlayerData);
        playerSerializer.savePlayerData(playerService.getPlayerData());
        GameTile gameTile = world.getGameTiles()[updatedY][updatedX][0];
        if (gameTile.getGameObject() != null) {
            int eventId = gameTile.getGameObject().getId();
            GameEvent event = gameController.getEventById(eventId);
            try {
                String eventResultJson = playerService.handleEvent(event);
                return ResponseEntity.ok(eventResultJson);
            } catch (JsonProcessingException e) {
                System.err.println("Error while processing event: " + e.getMessage());
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
            }
        }
        return ResponseEntity.status(HttpStatus.ACCEPTED).build();
    }

    /**
     * Create player response entity.
     *
     * @param playerName        the player name
     * @param playerDisplayName the player display name
     * @return the response entity
     * @throws IOException the io exception
     */

    @Operation(summary = "Create a new player",
            description = "This method creates a new player or loads existing player data based on the provided parameters.",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successful operation")
            })
    @PostMapping("/api/player")
    public ResponseEntity<String> createPlayer(@Parameter(in = ParameterIn.QUERY, description = "The player's name", required = true) @RequestParam String playerName,
                                               @Parameter(in = ParameterIn.QUERY, description = "The player's display name", required = true) @RequestParam String playerDisplayName) throws IOException {
        if (!playerSerializer.playerDataExists()) {
            UUID uuid = UUID.randomUUID();
            PlayerData newPlayerData = new PlayerData(playerName, playerDisplayName, uuid.toString(), 10, 10, new int[]{20, 20, 0}, new Stats(1, 1, 1, 1, 1, 1));
            playerService.createPlayer(newPlayerData);
            playerSerializer.savePlayerData(playerService.getPlayerData());
            return ResponseEntity.ok("Player created");
        } else {
            PlayerData existingPlayerData = playerSerializer.loadPlayerData();
            playerService.createPlayer(existingPlayerData);
            return ResponseEntity.ok("Player already exists");
        }
    }

    /**
     * Gets player data.
     *
     * @return the player data
     * @throws IOException the io exception
     */

    @Operation(summary = "Get player data",
            description = "This method returns the player's data. If the player data does not exist, it loads the existing player data.",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successful operation",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = PlayerData.class)))
            })
    @GetMapping("/api/player")
    public ResponseEntity<PlayerData> getPlayerData() throws IOException {
        if (playerService.getPlayerData() == null) {
            PlayerData existingPlayerData = playerSerializer.loadPlayerData();
            playerService.createPlayer(existingPlayerData);
        }
        return ResponseEntity.ok(playerService.getPlayerData());
    }
}