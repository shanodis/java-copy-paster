package pl.mlodawski.minecard.util.worldgenerator;

import pl.mlodawski.minecard.model.world.ObjectType;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * The enum City size.
 */
public enum CitySize {
    /**
     * Small city size.
     */
    SMALL(3, Arrays.asList(ObjectType.HOUSE, ObjectType.HOUSE, ObjectType.HOUSE, ObjectType.MODERN_HOUSE)),
    /**
     * Medium city size.
     */
    MEDIUM(5, generateMediumCityBuildings()),
    /**
     * Large city size.
     */
    LARGE(7, generateLargeCityBuildings());

    private final int size;
    private final List<ObjectType> buildings;

    CitySize(int size, List<ObjectType> buildings) {
        this.size = size;
        this.buildings = buildings;
    }

    /**
     * Gets size.
     *
     * @return the size
     */
    public int getSize() {
        return size;
    }

    /**
     * Gets buildings.
     *
     * @return the buildings
     */
    public List<ObjectType> getBuildings() {
        return buildings;
    }

    /**
     * Generate medium city buildings list.
     * @return the list
     */
    private static List<ObjectType> generateMediumCityBuildings() {
        List<ObjectType> buildings = new ArrayList<>(Arrays.asList(ObjectType.HOUSE, ObjectType.HOUSE, ObjectType.MODERN_HOUSE, ObjectType.MODERN_HOUSE, ObjectType.MODERN_HOUSE_2));
        if (new SecureRandom().nextBoolean()) buildings.add(ObjectType.HOSPITAL);
        if (new SecureRandom().nextBoolean()) buildings.add(ObjectType.SHOP);
        if (new SecureRandom().nextBoolean()) buildings.add(ObjectType.HOTEL);
        if (new SecureRandom().nextBoolean()) buildings.add(ObjectType.BANK);
        return buildings;
    }

    /**
     * Generate large city buildings list.
     * @return the list
     */
    private static List<ObjectType> generateLargeCityBuildings() {
        return Arrays.asList(ObjectType.HOUSE, ObjectType.HOUSE, ObjectType.MODERN_HOUSE, ObjectType.MODERN_HOUSE, ObjectType.MODERN_HOUSE_2, ObjectType.MODERN_HOUSE_2, ObjectType.HOSPITAL, ObjectType.SHOP, ObjectType.HOTEL, ObjectType.BANK);
    }
}