package pl.mlodawski.minecard.config;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
import org.springframework.security.access.hierarchicalroles.RoleHierarchy;
import org.springframework.security.access.hierarchicalroles.RoleHierarchyImpl;
import org.springframework.security.authentication.AuthenticationDetailsSource;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import pl.mlodawski.minecard.model.user.User;
import pl.mlodawski.minecard.repository.UserRepository;
import pl.mlodawski.minecard.service.security.TotpService;
import pl.mlodawski.minecard.service.user.UserDetailsService;
import pl.mlodawski.minecard.util.jwt.JwtTokenFilter;
import pl.mlodawski.minecard.util.security.CustomWebAuthenticationDetails;


import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.security.config.Customizer.withDefaults;

/**
 * The type Security config.
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {


    @Autowired
    private TotpService totpService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserDetailsService userDetailsService;


    /**
     * B crypt password encoder b crypt password encoder.
     *
     * @return the b crypt password encoder
     */
    @Bean
    public BCryptPasswordEncoder bCryptPasswordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * Role hierarchy.
     *
     * @return the role hierarchy
     */
    @Bean
    public RoleHierarchy roleHierarchy() {
        RoleHierarchyImpl roleHierarchy = new RoleHierarchyImpl();
        String hierarchy = "ROLE_ADMIN > ROLE_MODERATOR > ROLE_USER";
        roleHierarchy.setHierarchy(hierarchy);
        return roleHierarchy;
    }

    /**
     * Security filter chain security filter chain.
     *
     * @param http the http
     * @return the security filter chain
     * @throws Exception the exception
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authenticationProvider(customAuthenticationProvider(bCryptPasswordEncoder()))
                .cors(AbstractHttpConfigurer::disable)
                .csrf(AbstractHttpConfigurer::disable)

                .authorizeHttpRequests(requests -> requests
                        .requestMatchers("/actuator/**").permitAll()
                ).authorizeHttpRequests(requests -> requests
                        .requestMatchers("/api-docs", "/api-docs/**").permitAll()
                ).authorizeHttpRequests(requests -> requests
                        .requestMatchers("/api/public/**").permitAll()
                ).authorizeHttpRequests(requests -> requests
                        .requestMatchers("/api/player/**","/api/world/**").authenticated()
                ).authorizeHttpRequests(requests -> requests
                                .requestMatchers("/api/jwt/**").permitAll()
                ).authorizeHttpRequests(requests -> requests
                                .requestMatchers("/api/user/**").permitAll()
                ).authorizeHttpRequests(requests -> requests
                        .requestMatchers("/", "/login", "/login/**", "/register/**", "/api/user/register").permitAll()
                ).authorizeHttpRequests(requests -> requests
                        .requestMatchers("/public/game/**").hasRole("PLAYER")
                        .requestMatchers("/moderator/**").hasAnyRole("MODERATOR")
                        .requestMatchers("/admin/**").hasAnyRole("ADMIN")
                        .requestMatchers("/user/**").hasAnyRole("USER")
                ).authorizeHttpRequests(requests -> requests
                        .requestMatchers("/public/**", "/", "/login", "/login/**", "/register/**", "/api/user/register").permitAll()
                        .anyRequest().authenticated()
                )
                .sessionManagement(sessionManagement -> sessionManagement
                        .sessionFixation().migrateSession()
                        .maximumSessions(1)
                        .maxSessionsPreventsLogin(false)
                        .expiredUrl("/login?expired"))

                .formLogin(form -> form
                        .loginPage("/login")
                        .permitAll()
                        .authenticationDetailsSource((AuthenticationDetailsSource<HttpServletRequest, WebAuthenticationDetails>) CustomWebAuthenticationDetails::new)
                        .successHandler(successHandler()).failureHandler(failureHandler())
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .invalidateHttpSession(true)
                        .deleteCookies("JSESSIONID")
                        .logoutSuccessUrl("/?logout"))
                .headers((headers) ->
                        headers
                                .contentTypeOptions(withDefaults())
                                .xssProtection(withDefaults())
                                .cacheControl(withDefaults())
                                .httpStrictTransportSecurity(withDefaults())
                                .frameOptions(withDefaults()
                                )).cors(withDefaults());

        return http.build();
    }

    /**
     * Success handler authentication success handler.
     *
     * @return the authentication success handler
     */
    @Bean
    public AuthenticationSuccessHandler successHandler() {
        return (httpServletRequest, httpServletResponse, authentication) -> {
            httpServletResponse.getWriter().append("OK");
            httpServletResponse.setStatus(200);
        };
    }

    /**
     * Failure handler authentication failure handler.
     *
     * @return the authentication failure handler
     */
    @Bean
    public AuthenticationFailureHandler failureHandler() {
        return (httpServletRequest, httpServletResponse, e) -> {
            httpServletResponse.getWriter().append("Authentication failure");
            httpServletResponse.setStatus(401);
        };
    }

    /**
     * Custom authentication provider custom authentication provider.
     * @param jwtTokenFilterService the jwt token filter service
     * @return the custom authentication provider
     */
    @Bean
    public FilterRegistrationBean<JwtTokenFilter> jwtFilter(@Autowired JwtTokenFilter jwtTokenFilterService) {
        FilterRegistrationBean<JwtTokenFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(jwtTokenFilterService);
        registrationBean.addUrlPatterns("/api/jwt/token/check");
        return registrationBean;
    }

    /**
     * Cors configuration source cors configuration source.
     *
     * @return the cors configuration source
     */
    @Bean
    CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(Arrays.asList("http://localhost:8080", "http://localhost:8081"));
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS", "HEAD"));
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }


    /**
     * Custom authentication provider.
     *
     * @param passwordEncoder the password encoder
     * @return the authentication provider
     */
    @Bean
    public AuthenticationProvider customAuthenticationProvider(PasswordEncoder passwordEncoder) {
        return new AuthenticationProvider() {

            @Override
            public Authentication authenticate(Authentication authentication) throws AuthenticationException {
                String username = authentication.getName();
                String password = (String) authentication.getCredentials();
                String totp = ((CustomWebAuthenticationDetails) authentication.getDetails()).getVerificationCode();
                User user = userRepository.findByUsername(username);
                if (user != null && passwordEncoder.matches(password, user.getPassword())) {
                    List<GrantedAuthority> authorities = user.getRoles().stream()
                            .map(role -> new SimpleGrantedAuthority("ROLE_" + role))
                            .collect(Collectors.toList());
                    if (user.isUsing2FA()) {
                        try {
                            if (totpService.verifyCode(user.getSecret2FA(), Integer.parseInt(totp))) {
                                return new UsernamePasswordAuthenticationToken(username, password, authorities);
                            } else {
                                throw new BadCredentialsException("Invalid 2FA code");
                            }
                        } catch (NumberFormatException e) {
                            throw new BadCredentialsException("Invalid 2FA code");
                        }
                    } else {
                        return new UsernamePasswordAuthenticationToken(username, password, authorities);
                    }
                } else {
                    throw new BadCredentialsException("Invalid username or password");
                }
            }

            @Override
            public boolean supports(Class<?> aClass) {
                return aClass.equals(UsernamePasswordAuthenticationToken.class);
            }
        };
    }
}
