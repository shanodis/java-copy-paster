package pl.mlodawski.minecard.util.Item;

import pl.mlodawski.minecard.model.player.PlayerData;

/**
 * The interface Use strategy.
 */
public interface UseStrategy {
    /**
     * Use.
     *
     * @param player the player
     */
    void use(PlayerData player);

    /**
     * Revert.
     *
     * @param player the player
     */
    void revert(PlayerData player);
}