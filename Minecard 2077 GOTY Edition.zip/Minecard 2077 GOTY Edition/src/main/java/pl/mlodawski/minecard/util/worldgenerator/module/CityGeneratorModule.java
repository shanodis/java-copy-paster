package pl.mlodawski.minecard.util.worldgenerator.module;

import org.springframework.stereotype.Component;
import pl.mlodawski.minecard.model.world.GameObject;
import pl.mlodawski.minecard.model.world.GameWorld;
import pl.mlodawski.minecard.model.world.ObjectType;
import pl.mlodawski.minecard.model.world.TileType;
import pl.mlodawski.minecard.util.worldgenerator.CitySize;
import pl.mlodawski.minecard.util.worldgenerator.StructureModule;

import java.util.List;
import java.util.Random;

/**
 * The type City generator module.
 */

public class CityGeneratorModule implements StructureModule {

    private static final int VILLAGE_DISTANCE_FROM_EDGE = 10;


    @Override
    public void generateStructure(GameWorld world, Random random) {
        int worldWidth = world.getWidth();
        int worldHeight = world.getHeight();

        if (worldWidth == 64 && worldHeight == 64) {
            generateStructuresFor64x64(world, random);
        } else if (worldWidth == 128 && worldHeight == 128) {
            generateStructuresFor128x128(world, random);
        } else if (worldWidth == 256 && worldHeight == 256) {
            generateStructuresFor256x256(world, random);
        }
    }

    private void generateStructuresFor64x64(GameWorld world, Random random) {
        generateVillage(world, random);
        generateCity(world, CitySize.SMALL, random);
        generateCity(world, CitySize.MEDIUM, random);
    }

    private void generateStructuresFor128x128(GameWorld world, Random random) {
        generateVillage(world, random);
        generateCity(world, CitySize.SMALL, random);
        generateCity(world, CitySize.MEDIUM, random);
        generateCity(world, CitySize.LARGE, random);

    }

    private void generateStructuresFor256x256(GameWorld world, Random random) {
        generateVillage(world, random);
        generateCity(world, CitySize.SMALL, random);
        generateCity(world, CitySize.MEDIUM, random);
        generateCity(world, CitySize.LARGE, random);
    }

    private void generateVillage(GameWorld world, Random random) {
        int x = random.nextInt(world.getWidth() - VILLAGE_DISTANCE_FROM_EDGE * 2) + VILLAGE_DISTANCE_FROM_EDGE;
        int y = random.nextInt(world.getHeight() - VILLAGE_DISTANCE_FROM_EDGE * 2) + VILLAGE_DISTANCE_FROM_EDGE;

        if (canGenerateVillage(world, x, y)) {
            generateCountryHouse(world, x, y);
            generateCountryHouse(world, x + 1, y);
        }
    }

    private boolean canGenerateVillage(GameWorld world, int x, int y) {
        int worldWidth = world.getWidth();
        int worldHeight = world.getHeight();

        return x >= VILLAGE_DISTANCE_FROM_EDGE && y >= VILLAGE_DISTANCE_FROM_EDGE &&
                x + 1 < worldWidth - VILLAGE_DISTANCE_FROM_EDGE &&
                y < worldHeight - VILLAGE_DISTANCE_FROM_EDGE;
    }

    private void generateCountryHouse(GameWorld world, int x, int y) {
        ObjectType objectType = ObjectType.COUNTRY_HOUSE;
        GameObject gameObject = new GameObject(objectType.ordinal(), objectType);
        world.getGameTiles()[x][y][0].setGameObject(gameObject);
    }

    private void generateCity(GameWorld world, CitySize citySize, Random random) {
        int cityWidth = citySize.getSize();
        int cityHeight = citySize.getSize();
        List<ObjectType> buildings = citySize.getBuildings();

        int x = random.nextInt(world.getWidth() - cityWidth);
        int y = random.nextInt(world.getHeight() - cityHeight);

        if (canGenerateCity(world, x, y, cityWidth, cityHeight)) {
            generateRoads(world, x, y, cityWidth, cityHeight);
            placeBuildings(world, x, y, cityWidth, cityHeight, buildings, random);
        }
    }

    private boolean canGenerateCity(GameWorld world, int x, int y, int cityWidth, int cityHeight) {
        for (int dx = 0; dx < cityWidth; dx++) {
            for (int dy = 0; dy < cityHeight; dy++) {
                if (!isInsideWorld(world, x + dx, y + dy) || world.getGameTiles()[x + dx][y + dy][0].getTileType() == TileType.ROAD) {
                    return false;
                }
            }
        }
        return true;
    }

    private void generateRoads(GameWorld world, int x, int y, int cityWidth, int cityHeight) {
        // Generate horizontal road
        for (int dx = 0; dx < cityWidth; dx++) {
            int z = 0;
            TileType tileType = TileType.ROAD;
            world.getGameTiles()[x + dx][y][z].setTileType(tileType);
        }

        // Generate vertical road
        for (int dy = 0; dy < cityHeight; dy++) {
            int z = 0;
            TileType tileType = TileType.ROAD;
            world.getGameTiles()[x][y + dy][z].setTileType(tileType);
        }
    }

    private void placeBuildings(GameWorld world, int x, int y, int cityWidth, int cityHeight, List<ObjectType> buildings, Random random) {
        for (int dx = 0; dx < cityWidth; dx++) {
            for (int dy = 0; dy < cityHeight; dy++) {
                if (dx % 2 == 0 && dy % 2 == 0) {
                    int buildingIndex = random.nextInt(buildings.size());
                    ObjectType objectType = buildings.get(buildingIndex);

                    GameObject gameObject = new GameObject(objectType.ordinal(), objectType);
                    world.getGameTiles()[x + dx][y + dy][0].setGameObject(gameObject);
                }
            }
        }
    }

    private boolean isInsideWorld(GameWorld world, int x, int y) {
        return x >= 0 && x < world.getWidth() && y >= 0 && y < world.getHeight();
    }
}