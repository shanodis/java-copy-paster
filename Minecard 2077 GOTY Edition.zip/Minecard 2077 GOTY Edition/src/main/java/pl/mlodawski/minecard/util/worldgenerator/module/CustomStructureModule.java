package pl.mlodawski.minecard.util.worldgenerator.module;

import pl.mlodawski.minecard.model.world.GameObject;
import pl.mlodawski.minecard.model.world.GameTile;
import pl.mlodawski.minecard.model.world.GameWorld;
import pl.mlodawski.minecard.model.world.TileType;
import pl.mlodawski.minecard.util.worldgenerator.StructureModule;

import java.util.Random;

/**
 * The type Custom structure module.
 */
public class CustomStructureModule  implements StructureModule {

    private final GameTile[][][] structures;
    private final int structureSize;

    /**
     * Instantiates a new Custom structure module.
     *
     * @param structures    the structures
     * @param structureSize the structure size
     * @param maxRange      the max range
     */
    public CustomStructureModule(GameTile[][][] structures, int structureSize, int maxRange) {
        this.structures = structures;
        this.structureSize = structureSize;
    }

    @Override
    public void generateStructure(GameWorld world, Random random) {
        int worldWidth = world.getWidth();
        int worldHeight = world.getHeight();
        int minDistanceFromEdge = 9;

        for (GameTile[][] structure : structures) {
            int offsetX = random.nextInt(worldWidth - structureSize - minDistanceFromEdge * 2) + minDistanceFromEdge;
            int offsetY = random.nextInt(worldHeight - structureSize - minDistanceFromEdge * 2) + minDistanceFromEdge;

            for (int x = 0; x < structureSize; x++) {
                for (int y = 0; y < structureSize; y++) {
                    int tileX = structure[x][y].getX() + offsetX;
                    int tileY = structure[x][y].getY() + offsetY;
                    int tileZ = structure[x][y].getZ();

                    if (tileX >= 0 && tileX < worldWidth && tileY >= 0 && tileY < worldHeight) {
                        TileType tileType = structure[x][y].getTileType();
                        GameObject gameObject = structure[x][y].getGameObject();

                        world.getGameTiles()[tileX][tileY][tileZ].setTileType(tileType);
                        world.getGameTiles()[tileX][tileY][tileZ].setGameObject(gameObject);
                    }
                }
            }
        }
    }
}
