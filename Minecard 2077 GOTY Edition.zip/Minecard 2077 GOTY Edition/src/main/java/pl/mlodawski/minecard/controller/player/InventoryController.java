package pl.mlodawski.minecard.controller.player;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pl.mlodawski.minecard.model.item.Item;
import pl.mlodawski.minecard.model.player.PlayerData;
import pl.mlodawski.minecard.service.player.PlayerService;
import pl.mlodawski.minecard.util.player.PlayerSerializer;

import java.io.IOException;
import java.util.List;


/**
 * The type Inventory controller.
 */
@Tag(name = "Inventory", description = "The inventory API")
@RestController
public class InventoryController {

    @Autowired
    private PlayerService playerService;

    @Autowired
    private PlayerSerializer playerSerializer;


    @Operation(summary = "Get player's inventory", description = "This API endpoint returns the inventory of the player")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved player's inventory",
                    content = @Content(array = @ArraySchema(schema = @Schema(implementation = Item.class)))),
            @ApiResponse(responseCode = "404", description = "Player not found")
    })
    @GetMapping("/api/player/inventory")
    public ResponseEntity<List<Item>> getInventory() {
        PlayerData playerData = playerService.getPlayerData();
        if (playerData != null) {
            return ResponseEntity.ok(playerData.getInventory());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Add item.
     *
     * @param item the item
     * @return the response entity
     * @throws IOException the io exception
     */
    @Operation(summary = "Add an item to the player's inventory")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Item added to the inventory", content = @io.swagger.v3.oas.annotations.media.Content(schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = String.class))),
            @ApiResponse(responseCode = "404", description = "Player not found")
    })
    @PostMapping("/api/player/inventory/add")
    public ResponseEntity<String> addItem(@Parameter(description = "The item to add", content = @io.swagger.v3.oas.annotations.media.Content(schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = Item.class)))
                                          @RequestBody Item item) throws IOException {
        PlayerData playerData = playerService.getPlayerData();
        if (playerData != null) {
            playerData.addItemToInventory(item);
            playerSerializer.savePlayerData(playerData);
            return ResponseEntity.ok("Item added to the inventory.");
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Remove item.
     *
     * @param itemId the item id
     * @return the response entity
     * @throws IOException the io exception
     */
    @Operation(summary = "Remove an item from the player's inventory")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Item removed from the inventory",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = String.class))),
            @ApiResponse(responseCode = "404", description = "Player not found or item not found in the inventory")
    })
    @DeleteMapping("/api/player/inventory/remove/{itemId}")
    public ResponseEntity<String> removeItem(@Parameter(description = "The id of the item to remove", required = true,
            schema = @Schema(implementation = String.class))
                                             @PathVariable String itemId) throws IOException {
        PlayerData playerData = playerService.getPlayerData();
        if (playerData != null) {
            boolean isRemoved = playerData.removeItemFromInventory(itemId);
            if (isRemoved) {
                playerSerializer.savePlayerData(playerData);
                return ResponseEntity.ok("Item removed from the inventory.");
            } else {
                return new ResponseEntity<>("Item not found in the inventory.", HttpStatus.NOT_FOUND);
            }
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Equip item.
     *
     * @param itemId the item id
     * @return the response entity
     * @throws IOException the io exception
     */
    @Operation(summary = "Equip an item in the player's inventory")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Item equipped",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = String.class))),
            @ApiResponse(responseCode = "404", description = "Player not found")
    })
    @PutMapping("/api/player/inventory/equip/{itemId}")
    public ResponseEntity<String> equipItem(@Parameter(description = "The id of the item to equip", required = true,
            schema = @Schema(implementation = String.class))
                                            @PathVariable String itemId) throws IOException {
        PlayerData playerData = playerService.getPlayerData();
        if (playerData != null) {
            playerData.equipItem(itemId);
            playerSerializer.savePlayerData(playerData);
            return ResponseEntity.ok("Item equipped.");
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Unequip item.
     *
     * @param itemId the item id
     * @return the response entity
     * @throws IOException the io exception
     */
    @Operation(summary = "Unequip an item in the player's inventory")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Item unequipped",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = String.class))),
            @ApiResponse(responseCode = "404", description = "Player not found")
    })
    @PutMapping("/api/player/inventory/unequip/{itemId}")
    public ResponseEntity<String> unequipItem(@Parameter(description = "The id of the item to unequip", required = true,
            schema = @Schema(implementation = String.class))
                                              @PathVariable String itemId) throws IOException {
        PlayerData playerData = playerService.getPlayerData();
        if (playerData != null) {
            playerData.unequipItem(itemId);
            playerSerializer.savePlayerData(playerData);
            return ResponseEntity.ok("Item unequipped.");
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Use item.
     *
     * @param itemId the item id
     * @return the response entity
     * @throws IOException the io exception
     */
    @Operation(summary = "Use an item in the player's inventory")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Item used",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = String.class))),
            @ApiResponse(responseCode = "404", description = "Player not found")
    })
    @PutMapping("/api/player/inventory/use/{itemId}")
    public ResponseEntity<String> useItem(@Parameter(description = "The id of the item to use", required = true,
            schema = @Schema(implementation = String.class))
                                          @PathVariable String itemId) throws IOException {
        PlayerData playerData = playerService.getPlayerData();
        if (playerData != null) {
            playerData.useItem(itemId);
            playerSerializer.savePlayerData(playerData);
            return ResponseEntity.ok("Item used.");
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}