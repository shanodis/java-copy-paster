package pl.mlodawski.minecard.model.user;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Set;

/**
 * The type User dto.
 */
@Data
@AllArgsConstructor
public class UserDTO {
    private String id;
    private String username;
    private boolean enabled;
    private Set<String> roles;
    private boolean isUsing2FA;

    /**
     * Instantiates a new User dto.
     */
    public UserDTO() {
    }
}