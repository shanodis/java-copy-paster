package pl.mlodawski.minecard.controller.security;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import pl.mlodawski.minecard.model.user.ChangeUserPasswordDTO;
import pl.mlodawski.minecard.model.user.RegisterUserDTO;
import pl.mlodawski.minecard.model.user.User;
import pl.mlodawski.minecard.model.user.UserDTO;
import pl.mlodawski.minecard.repository.UserRepository;
import pl.mlodawski.minecard.service.user.UserDetailsService;

import java.security.Principal;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * The type User controller.
 */
@RestController
public class UserController {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private UserDetailsService userService;

    private final BCryptPasswordEncoder bCryptPasswordEncoder;

    public UserController(BCryptPasswordEncoder bCryptPasswordEncoder) {
        this.bCryptPasswordEncoder = bCryptPasswordEncoder;
    }

    /**
     * Current user name response entity.
     *
     * @param principal the principal
     * @return the response entity
     */
    @GetMapping("/api/user")
    public ResponseEntity<UserDTO> currentUserName(Principal principal) {
        if (principal == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Principal is null");
        }
        User user = userRepository.findByUsername(principal.getName());
        if (user == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found");
        }
        UserDTO userDTO = new UserDTO();
        userDTO.setId(user.getId());
        userDTO.setUsername(user.getUsername());
        userDTO.setEnabled(user.isEnabled());
        userDTO.setRoles(user.getRoles());
        userDTO.setUsing2FA(user.isUsing2FA());

        return new ResponseEntity<>(userDTO, HttpStatus.OK);
    }

    @PostMapping("/api/user/register")
    public ResponseEntity<String> registerUser(@Valid @RequestBody RegisterUserDTO registerUserDTO) {
        User user = userRepository.findByUsername(registerUserDTO.getUsername());
        if (user != null) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "User with that username already exists");
        }
        Set<String> userRoles = new HashSet<>(List.of("USER"));
        userService.addUser(registerUserDTO.getUsername(), registerUserDTO.getPassword(), true, userRoles);
        return ResponseEntity.ok("User was added successfully");
    }

    @PutMapping("/api/user/change-password")
    public ResponseEntity<String> changeUserPassword(@Valid @RequestBody ChangeUserPasswordDTO changeUserPasswordDTO, Principal principal) {
        if (principal == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Principal is null");
        }

        User user = userRepository.findByUsername(principal.getName());

        if (user == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found");
        }

        if (!bCryptPasswordEncoder.matches(changeUserPasswordDTO.getOldPassword(), user.getPassword())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Password provided doesn't match actual password, Request Denied");
        }

        user.setPassword(bCryptPasswordEncoder.encode(changeUserPasswordDTO.getNewPassword()));

        userRepository.save(user);

        return ResponseEntity.ok("Password was changed successfully");
    }
}
