package pl.mlodawski.minecard.model.world;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * The enum Tile type.
 */
@JsonSerialize
public enum TileType {
    /**
     * Mountain tile type.
     */
    MOUNTAIN("⛰"),
    /**
     * Volcano tile type.
     */
    VOLCANO("🌋"),
    /**
     * Desert tile type.
     */
    DESERT("🏜"),
    /**
     * Beach tile type.
     */
    BEACH("🏖"),
    /**
     * Water tile type.
     */
    WATER("🌊"),
    /**
     * Road tile type.
     */
    ROAD("🌫"),
    /**
     * Earth tile type.
     */
    EARTH("🏞"),
    /**
     * Grass tile type.
     */
    GRASS("🏞"),
    /**
     * Sand tile type.
     */
    SAND("🏜️"),
    /**
     * Lava tile type.
     */
    LAVA("🌋");

    private final String symbol;

    TileType(String symbol) {
        this.symbol = symbol;
    }

    /**
     * Gets symbol.
     *
     * @return the symbol
     */
    public String getSymbol() {
        return symbol;
    }
}