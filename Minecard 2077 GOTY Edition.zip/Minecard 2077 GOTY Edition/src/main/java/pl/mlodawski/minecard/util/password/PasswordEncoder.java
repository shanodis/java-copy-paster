package pl.mlodawski.minecard.util.password;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * The type Password encoder.
 */
@Component
public class PasswordEncoder {

    /**
     * Password encoder string.
     *
     * @param password the password
     * @return the string
     */
    public String passwordEncoder(String password) {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        return passwordEncoder.encode(password);
    }
}
