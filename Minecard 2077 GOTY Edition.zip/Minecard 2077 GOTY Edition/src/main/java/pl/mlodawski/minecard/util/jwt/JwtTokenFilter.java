package pl.mlodawski.minecard.util.jwt;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import pl.mlodawski.minecard.service.security.JwtService;


import java.io.IOException;

/**
 * This class is responsible for filtering requests and checking if the token is valid.
 */

@Component
public class JwtTokenFilter extends OncePerRequestFilter {

   @Autowired
   JwtService jwtTokenProviderService;


    /**
     *  This method is responsible for filtering requests and checking if the token is valid.
     * @param request - request
     * @param response - response
     * @param filterChain - filterChain
     * @throws IOException  - IOException
     * @throws ServletException - ServletException
     */
    @Override
    public void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws IOException, ServletException {

       String token = jwtTokenProviderService.resolveToken(request.getHeader("Authorization"));

        if (token != null && jwtTokenProviderService.validateToken(token)) {
           Authentication auth = jwtTokenProviderService.getAuthentication(token);
         SecurityContextHolder.getContext().setAuthentication(auth);
       } else {
           response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Invalid or missing token");
           return;
      }

      filterChain.doFilter(request, response);
    }
}
