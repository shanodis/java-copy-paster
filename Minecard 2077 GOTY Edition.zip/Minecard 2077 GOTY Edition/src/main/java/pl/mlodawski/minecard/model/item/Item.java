package pl.mlodawski.minecard.model.item;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import pl.mlodawski.minecard.model.player.PlayerData;
import pl.mlodawski.minecard.util.Item.*;
import pl.mlodawski.minecard.util.Item.strategy.*;
import pl.mlodawski.minecard.util.Item.UseStrategy;

/**
 * The type Item.
 */
@Data
@AllArgsConstructor
@Schema(description = "Details about the item")
public class Item {

    @Schema(description = "The unique id of the item")
    private String id;
    @Schema(description = "The name of the item")
    private String name;
    @Schema(description = "The type of the item")
    private ItemType itemType;
    @Schema(description = "The category of the item")
    private ItemCategory itemCategory;
    @Schema(description = "Indicates whether the item is currently equipped or not")
    private boolean currentlyEquipped;
    @Schema(description = "Indicates whether the item can be equipped or not")
    private boolean canBeEquipped;
    @Schema(description = "The quantity of the item")
    private int quantity;
    @JsonIgnore
    @Schema(description = "The strategy of using the item", hidden = true)
    private UseStrategy useStrategy;

    /**
     * Instantiates a new Item.
     *
     * @param id            the id
     * @param name          the name
     * @param itemType      the item type
     * @param itemCategory  the item category
     * @param canBeEquipped they can be equipped
     * @param quantity      the quantity
     * @param useStrategy   the use strategy
     */
    public Item(String id, String name, ItemType itemType, ItemCategory itemCategory, boolean canBeEquipped, int quantity, UseStrategy useStrategy) {
        this.id = id;
        this.name = name;
        this.itemType = itemType;
        this.itemCategory = itemCategory;
        this.currentlyEquipped = false;
        this.canBeEquipped = canBeEquipped;
        this.quantity = quantity;
        this.useStrategy = useStrategy;
    }

    /**
     * Player use item.
     *
     * @param playerData the player data
     */
    public void use(PlayerData playerData) {
        System.out.println("Using item " + this.id + " of type " + this.itemType.getDisplayName() + "...");
        switch (this.itemType) {
            case STRAWBERRY -> new FoodUseStrategy().use(playerData);
            case AXE -> new ToolsUseStrategy().use(playerData);
            case HEADGEAR_1 -> new ClothingUseStrategy().use(playerData);
            case HEADGEAR_2 -> new ClothingUseStrategy().use(playerData);
            case HEADGEAR_3 -> new ClothingUseStrategy().use(playerData);
            case HEADGEAR_4 -> new ClothingUseStrategy().use(playerData);
            case SHOES_1 -> new ClothingUseStrategy().use(playerData);
            case SHOES_2 -> new ClothingUseStrategy().use(playerData);
            case SHOES_3 -> new ClothingUseStrategy().use(playerData);
            case SHOES_4 -> new ClothingUseStrategy().use(playerData);
            case TOP_1 -> new ClothingUseStrategy().use(playerData);
            case TOP_2 -> new ClothingUseStrategy().use(playerData);
            case TOP_3 -> new ClothingUseStrategy().use(playerData);
            case TOP_4 -> new ClothingUseStrategy().use(playerData);
            case TOP_5 -> new ClothingUseStrategy().use(playerData);
            case TOP_6 -> new ClothingUseStrategy().use(playerData);
            case TOP_7 -> new ClothingUseStrategy().use(playerData);
            case BOTTOMS_1 -> new ClothingUseStrategy().use(playerData);
            case PHONE_1 -> new ElectronicsUseStrategy().use(playerData);
            case PHONE_2 -> new ElectronicsUseStrategy().use(playerData);
            case LAPTOP_1 -> new ElectronicsUseStrategy().use(playerData);
            case DISK -> new DiskUseStrategy().use(playerData);
            case DVD -> new DiskUseStrategy().use(playerData);
            case SCROLL -> new BookUseStrategy().use(playerData);
            case BOOK -> new BookUseStrategy().use(playerData);
            case FLOPPY_DISK -> new DiskUseStrategy().use(playerData);
            case FLASHLIGHT -> new ElectronicsUseStrategy().use(playerData);
            case CAMERA -> new ElectronicsUseStrategy().use(playerData);
            case TOMATO -> new FoodUseStrategy().use(playerData);
            case MELON -> new FoodUseStrategy().use(playerData);
            case WATERMELON -> new FoodUseStrategy().use(playerData);
            case MANGO -> new FoodUseStrategy().use(playerData);
            case FALAFEL -> new FoodUseStrategy().use(playerData);
            case SANDWICH -> new FoodUseStrategy().use(playerData);
            case ICE_CREAM -> new FoodUseStrategy().use(playerData);
            case MEDICINE -> new FoodUseStrategy().use(playerData);
            case IDENTITY_CARD -> new IdentityCardUseStrategy().use(playerData);
            case PICKAXE -> new ToolsUseStrategy().use(playerData);
            case HAMMER -> new ToolsUseStrategy().use(playerData);
            default ->
                    throw new IllegalArgumentException("Unknown use strategy for the object type: " + this.itemType);
        }
    }

    /**
     * Player revert item from eq.
     *
     * @param playerData the player data
     */
    public void revert(PlayerData playerData) {
        System.out.println("Revert item " + this.id + " of type " + this.itemType.getDisplayName() + "...");
        switch (this.itemType) {
            case AXE -> new ToolsUseStrategy().revert(playerData);
            case HEADGEAR_1 -> new ClothingUseStrategy().revert(playerData);
            case HEADGEAR_2 -> new ClothingUseStrategy().revert(playerData);
            case HEADGEAR_3 -> new ClothingUseStrategy().revert(playerData);
            case HEADGEAR_4 -> new ClothingUseStrategy().revert(playerData);
            case SHOES_1 -> new ClothingUseStrategy().revert(playerData);
            case SHOES_2 -> new ClothingUseStrategy().revert(playerData);
            case SHOES_3 -> new ClothingUseStrategy().revert(playerData);
            case SHOES_4 -> new ClothingUseStrategy().revert(playerData);
            case TOP_1 -> new ClothingUseStrategy().revert(playerData);
            case TOP_2 -> new ClothingUseStrategy().revert(playerData);
            case TOP_3 -> new ClothingUseStrategy().revert(playerData);
            case TOP_4 -> new ClothingUseStrategy().revert(playerData);
            case TOP_5 -> new ClothingUseStrategy().revert(playerData);
            case TOP_6 -> new ClothingUseStrategy().revert(playerData);
            case TOP_7 -> new ClothingUseStrategy().revert(playerData);
            case BOTTOMS_1 -> new ClothingUseStrategy().revert(playerData);
            case PHONE_1 -> new ElectronicsUseStrategy().revert(playerData);
            case PHONE_2 -> new ElectronicsUseStrategy().revert(playerData);
            case LAPTOP_1 -> new ElectronicsUseStrategy().revert(playerData);
            case DISK -> new DiskUseStrategy().revert(playerData);
            case DVD -> new DiskUseStrategy().revert(playerData);
            case SCROLL -> new BookUseStrategy().revert(playerData);
            case BOOK -> new BookUseStrategy().revert(playerData);
            case FLOPPY_DISK -> new DiskUseStrategy().revert(playerData);
            case FLASHLIGHT -> new ElectronicsUseStrategy().revert(playerData);
            case CAMERA -> new ElectronicsUseStrategy().revert(playerData);
            case IDENTITY_CARD -> new IdentityCardUseStrategy().revert(playerData);
            case PICKAXE -> new ToolsUseStrategy().revert(playerData);
            case HAMMER -> new ToolsUseStrategy().revert(playerData);
            default ->
                    throw new IllegalArgumentException("Unknown use strategy for the object type:" + this.itemType);
        }
    }


    /**
     * Instantiates a new Item.
     */
    public Item() {
    }
}