package pl.mlodawski.minecard.util.player;

import pl.mlodawski.minecard.model.player.PlayerData;

/**
 * The interface Game event.
 */
public interface GameEvent {
    /**
     * Execute event result.
     *
     * @param playerData the player data
     * @return the event result
     */
    EventResult execute(PlayerData playerData);
}