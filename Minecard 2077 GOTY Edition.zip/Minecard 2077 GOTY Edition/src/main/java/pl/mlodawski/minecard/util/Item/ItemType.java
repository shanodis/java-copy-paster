package pl.mlodawski.minecard.util.Item;


import io.swagger.v3.oas.annotations.media.Schema;

/**
 * The enum Item type.
 */
@Schema(description = "Types of items")
public enum ItemType {
    /**
     * The Headgear 1.
     */
    HEADGEAR_1("Headgear 1", true, "🕶️"),
    /**
     * The Headgear 2.
     */
    HEADGEAR_2("Headgear 2", true, "🪖"),
    /**
     * The Headgear 3.
     */
    HEADGEAR_3("Headgear 3", true, "🧢"),
    /**
     * The Headgear 4.
     */
    HEADGEAR_4("Headgear 4", true, "🥽"),
    /**
     * The Shoes 1.
     */
    SHOES_1("Shoes 1", true, "🥾"),
    /**
     * The Shoes 2.
     */
    SHOES_2("Shoes 2", true, "👞"),
    /**
     * The Shoes 3.
     */
    SHOES_3("Shoes 3", true, "👟"),
    /**
     * The Shoes 4.
     */
    SHOES_4("Shoes 4", true, "👢"),
    /**
     * The Top 1.
     */
    TOP_1("Top 1", true, "👕"),
    /**
     * The Top 2.
     */
    TOP_2("Top 2", true, "👔"),
    /**
     * The Top 3.
     */
    TOP_3("Top 3", true, "👗"),
    /**
     * The Top 4.
     */
    TOP_4("Top 4", true, "🥻"),
    /**
     * The Top 5.
     */
    TOP_5("Top 5", true, "🧥"),
    /**
     * The Top 6.
     */
    TOP_6("Top 6", true, "👘"),
    /**
     * The Top 7.
     */
    TOP_7("Top 7", true, "👚"),
    /**
     * The Bottoms 1.
     */
    BOTTOMS_1("Bottoms 1", true, "👖"),
    /**
     * The Phone 1.
     */
    PHONE_1("Phone 1", true, "📱"),
    /**
     * The Phone 2.
     */
    PHONE_2("Phone 2", true, "📟"),
    /**
     * The Laptop 1.
     */
    LAPTOP_1("Laptop 1", true, "💻"),
    /**
     * Disk item type.
     */
    DISK("Disk", false, "💽"),
    /**
     * Dvd item type.
     */
    DVD("DVD", false, "📀"),
    /**
     * Scroll item type.
     */
    SCROLL("Scroll", false, "📜"),
    /**
     * Book item type.
     */
    BOOK("Book", false, "📗"),
    /**
     * The Floppy disk.
     */
    FLOPPY_DISK("Floppy Disk", false, "💾"),
    /**
     * Flashlight item type.
     */
    FLASHLIGHT("Flashlight", true, "🔦"),
    /**
     * Camera item type.
     */
    CAMERA("Camera", true, "📷"),
    /**
     * Tomato item type.
     */
    TOMATO("Tomato", true, "🍅"),
    /**
     * Melon item type.
     */
    MELON("Melon", true, "🍈"),
    /**
     * Watermelon item type.
     */
    WATERMELON("Watermelon", true, "🍉"),
    /**
     * Strawberry item type.
     */
    STRAWBERRY("Strawberry", true, "🍓"),
    /**
     * Mango item type.
     */
    MANGO("Mango", true, "🥭"),
    /**
     * Falafel item type.
     */
    FALAFEL("Falafel", true, "🧆"),
    /**
     * Sandwich item type.
     */
    SANDWICH("Sandwich", true, "🥪"),
    /**
     * The Ice cream.
     */
    ICE_CREAM("Ice Cream", true, "🍨"),
    /**
     * Medicine item type.
     */
    MEDICINE("Medicine", true, "💊"),
    /**
     * The Identity card.
     */
    IDENTITY_CARD("Identity Card", false, "🪪"),
    /**
     * Pickaxe item type.
     */
    PICKAXE("Pickaxe", true, "⛏️"),
    /**
     * Hammer item type.
     */
    HAMMER("Hammer", true, "🔨"),
    /**
     * Axe item type.
     */
    AXE("Axe", true, "🪓");

    private String displayName;
    private boolean canBeEquipped;
    private String emoji;

    ItemType(String displayName, boolean canBeEquipped, String emoji) {
        this.displayName = displayName;
        this.canBeEquipped = canBeEquipped;
        this.emoji = emoji;
    }

    /**
     * Gets display name.
     *
     * @return the display name
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Can be equipped boolean.
     *
     * @return the boolean
     */
    public boolean canBeEquipped() {
        return canBeEquipped;
    }

    /**
     * Gets emoji.
     *
     * @return the emoji
     */
    public String getEmoji() {
        return emoji;
    }

    ItemType() {
    }
}