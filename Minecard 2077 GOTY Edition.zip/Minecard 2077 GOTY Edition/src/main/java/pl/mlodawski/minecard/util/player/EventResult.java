package pl.mlodawski.minecard.util.player;

/**
 * The type Event result.
 */
public class EventResult {
    private final String title;
    private final String description;

    /**
     * Instantiates a new Event result.
     *
     * @param title       the title
     * @param description the description
     */
    public EventResult(String title, String description) {
        this.title = title;
        this.description = description;
    }

    /**
     * Gets title.
     *
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * Gets description.
     *
     * @return the description
     */
    public String getDescription() {
        return description;
    }
}
