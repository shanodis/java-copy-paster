package pl.mlodawski.minecard.util.time;

import org.apache.commons.net.ntp.NTPUDPClient;
import org.apache.commons.net.ntp.TimeInfo;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.InetAddress;

/**
 * The type Ntp component.
 */
@Component
public class NtpComponent {

    private static final String NTP_SERVER = "pool.ntp.org";

    /**
     * Gets current time.
     *
     * @return the current time
     * @throws IOException the io exception
     */
    public long getCurrentTime() throws IOException {
        NTPUDPClient client = new NTPUDPClient();
        client.setDefaultTimeout(10000);

        try {
            client.open();
            InetAddress hostAddr = InetAddress.getByName(NTP_SERVER);
            TimeInfo timeInfo = client.getTime(hostAddr);
            timeInfo.computeDetails();
            return timeInfo.getReturnTime();
        } finally {
            client.close();
        }
    }
}