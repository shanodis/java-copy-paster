package pl.mlodawski.minecard.util.Item.strategy;


import pl.mlodawski.minecard.model.player.PlayerData;
import pl.mlodawski.minecard.util.Item.UseStrategy;

/**
 * The type Book use strategy.
 */
public class BookUseStrategy implements UseStrategy {
    @Override
    public void use(PlayerData player) {
        player.getStats().setIntelligence(player.getStats().getIntelligence() + 5);
    }

    @Override
    public void revert(PlayerData player) {
        player.getStats().setIntelligence(player.getStats().getIntelligence() - 5);
    }


}
