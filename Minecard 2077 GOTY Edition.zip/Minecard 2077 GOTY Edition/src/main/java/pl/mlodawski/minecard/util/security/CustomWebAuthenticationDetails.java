package pl.mlodawski.minecard.util.security;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.security.web.authentication.WebAuthenticationDetails;

/**
 * The type Custom web authentication details.
 */
public class CustomWebAuthenticationDetails extends WebAuthenticationDetails {

    private final String verificationCode;

    /**
     * Instantiates a new Custom web authentication details.
     *
     * @param request the request
     */
    public CustomWebAuthenticationDetails(HttpServletRequest request) {
        super(request);
        verificationCode = request.getParameter("totp");
    }

    /**
     * Gets verification code.
     *
     * @return the verification code
     */
    public String getVerificationCode() {
        return verificationCode;
    }
}
