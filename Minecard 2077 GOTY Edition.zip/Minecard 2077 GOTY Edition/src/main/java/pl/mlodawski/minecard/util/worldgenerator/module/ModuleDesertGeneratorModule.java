package pl.mlodawski.minecard.util.worldgenerator.module;

import pl.mlodawski.minecard.model.world.*;
import pl.mlodawski.minecard.util.worldgenerator.PerlinNoiseGenerator;
import pl.mlodawski.minecard.util.worldgenerator.TerrainModule;

import java.util.Random;

/**
 * The type Module desert generator module.
 */
public class ModuleDesertGeneratorModule implements TerrainModule {

    @Override
    public void generateTerrain(GameWorld world, Random random) {
        PerlinNoiseGenerator perlin = new PerlinNoiseGenerator(random.nextLong());
        GameTile[][][] tiles = world.getGameTiles();
        int centerX = world.getWidth() / 2;
        int centerY = world.getHeight() / 2;
        int desertSize = 15; // Maximum size of the desert area

        // Loop over the tiles and generate the desert area around the center
        for (int x = centerX - desertSize / 2; x <= centerX + desertSize / 2; x++) {
            for (int y = centerY - desertSize / 2; y <= centerY + desertSize / 2; y++) {
                if (x >= 0 && x < tiles.length && y >= 0 && y < tiles[0].length) {
                    double noiseValue = perlin.noise(x / 10.0, y / 10.0);
                    // Chance for a tile to be desert
                    double desertChance = 0.40;
                    if (noiseValue < desertChance) {
                        tiles[x][y][0].setTileType(TileType.SAND);

                        // Chance for a desert tile to have a cactus
                        double cactusChance = 0.6;
                        // Chance for a desert tile to have wood
                        double rockChance = 0.05;
                        if (random.nextDouble() < cactusChance) {
                            tiles[x][y][0].setGameObject(new GameObject(ObjectType.CACTUS.ordinal(), ObjectType.CACTUS));
                        } else if (random.nextDouble() < rockChance) {
                            tiles[x][y][0].setGameObject(new GameObject(ObjectType.ROCK.ordinal(), ObjectType.ROCK));
                        }
                    }
                }
            }
        }
    }
}