package pl.mlodawski.minecard.controller.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import pl.mlodawski.minecard.util.password.PasswordEncoder;


/**
 * The type Password encoder controller.
 */
@RequestMapping("/api/public")
@RestController
public class PasswordEncoderController {

    /**
     * The Password encoder.
     */
    @Autowired
    PasswordEncoder passwordEncoder;

    /**
     * Encode password response entity.
     *
     * @param password the password
     * @return the response entity
     */
    @GetMapping("/encode-password")
    public ResponseEntity<String> encodePassword(String password) {
        return new ResponseEntity<>(passwordEncoder.passwordEncoder(password), HttpStatus.OK);
    }
}
