package pl.mlodawski.minecard.config;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import jakarta.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.config.AbstractMongoClientConfiguration;
import org.springframework.data.mongodb.core.MongoTemplate;
import pl.mlodawski.minecard.model.security.MongoConfigModel;
import pl.mlodawski.minecard.util.mongo.MongoLoadConfig;


/**
 * The type Mongo config.
 */
@Configuration
public class MongoConfig extends AbstractMongoClientConfiguration {

    /**
     * The Mongo load config.
     */
    @Autowired
    MongoLoadConfig mongoLoadConfig;

    /**
     * The Mongo config.
     */
    MongoConfigModel mongoConfig = new MongoConfigModel();
    @Override
    @NotNull
    protected String getDatabaseName() {
        return mongoConfig.getDatabase();
    }

    @Override
    @NotNull
    public MongoClient mongoClient() {
         mongoConfig = mongoLoadConfig.mongoLoadConfig();
        return MongoClients.create(mongoConfig.generateConnectionString());
    }

    /**
     * Mongo template mongo template.
     *
     * @return the mongo template
     */
    @Bean
    public MongoTemplate mongoTemplate() {
        return new MongoTemplate(mongoClient(), getDatabaseName());
    }
}