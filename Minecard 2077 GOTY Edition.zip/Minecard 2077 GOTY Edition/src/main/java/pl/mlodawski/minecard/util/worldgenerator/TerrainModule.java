package pl.mlodawski.minecard.util.worldgenerator;

import pl.mlodawski.minecard.model.world.GameWorld;

import java.util.Random;

/**
 * The interface Terrain module.
 */
public interface TerrainModule {
    /**
     * Generate terrain.
     *
     * @param world  the world
     * @param random the random
     */
    void generateTerrain(GameWorld world, Random random);
}
