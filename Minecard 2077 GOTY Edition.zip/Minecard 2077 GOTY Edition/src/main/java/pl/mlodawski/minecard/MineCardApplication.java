package pl.mlodawski.minecard;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import pl.mlodawski.minecard.controller.security.UserInitController;
import pl.mlodawski.minecard.model.security.JWTSecret;

import java.io.IOException;

/**
 * The type Mine card application.
 */
@SpringBootApplication
public class MineCardApplication {

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {
        SpringApplication.run(MineCardApplication.class, args);
    }

    @Autowired
    private UserInitController userInitController;

    @PostConstruct public void chuj() {
        //userInitController.initializeUsers();
        //userInitController.siur();
    }

}


