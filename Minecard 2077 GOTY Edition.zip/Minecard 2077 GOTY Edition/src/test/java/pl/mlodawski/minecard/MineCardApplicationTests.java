package pl.mlodawski.minecard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * The type Mine card application tests.
 */
@SpringBootTest
class MineCardApplicationTests {

    /**
     * Context loads.
     */
    @Test
    void contextLoads() {
    }

}
