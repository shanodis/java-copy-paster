package pl.mlodawski.fibonaccicommand;

import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;


public class FibonacciCommandImp  {

    private final Plugin plugin;

    public FibonacciCommandImp(Plugin plugin) {
        this.plugin = plugin;
    }


    /**
     Wykonuje polecenie Fibonacci.
     @param sender nadawca polecenia
     @param args argumenty polecenia
     */
    public void execute(CommandSender sender, Object... args) {
        if (args.length == 1) {
            try {
                int n = Integer.parseInt(args[0].toString());
                int result = calculateFibonacci(n);

                sender.sendMessage("Wynik dla n = " + n + " to: " + result);
            } catch (NumberFormatException e) {
                sender.sendMessage("Wprowadzona wartość musi być liczbą całkowitą.");
            }
        } else {
            sender.sendMessage("Niepoprawna liczba argumentów.");
        }
    }

    /**
     Oblicza n-ty element ciągu Fibonacciego.
     @param n indeks elementu
     @return wartość n-tego elementu ciągu Fibonacciego
     */
    private int calculateFibonacci(int n) {
        if (n <= 0) {
            return 0;
        } else if (n == 1) {
            return 1;
        } else {
            int previous = 0;
            int current = 1;
            for (int i = 2; i <= n; i++) {
                int next = previous + current;
                previous = current;
                current = next;
            }
            return current;
        }
    }
}