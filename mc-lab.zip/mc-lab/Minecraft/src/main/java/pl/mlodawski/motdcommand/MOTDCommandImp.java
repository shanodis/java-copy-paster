package pl.mlodawski.motdcommand;

import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class MOTDCommandImp {

    private final Plugin plugin;

    public MOTDCommandImp(Plugin plugin) {
        this.plugin = plugin;
    }

    public void execute(CommandSender sender, String displayMethod, String target, String message) {
        if (sender instanceof Player) {
            Player player = (Player) sender;
            if (player.hasPermission("motd.write")) {
                if (target.equalsIgnoreCase("all")) {
                    for (Player targetPlayer : Bukkit.getOnlinePlayers()) {
                        displayMessage(targetPlayer, displayMethod, message);
                    }
                } else {
                    Player targetPlayer = Bukkit.getPlayer(target);
                    if (targetPlayer != null) {
                        displayMessage(targetPlayer, displayMethod, message);
                    } else {
                        player.sendMessage("Nie znaleziono gracza o podanej nazwie.");
                    }
                }
            } else {
                player.sendMessage("Nie masz uprawnień do korzystania z tej komendy.");
            }
        }
    }

    private void displayMessage(Player targetPlayer, String displayMethod, String message) {
        switch (displayMethod.toLowerCase()) {
            case "title":
                targetPlayer.sendTitle(message, "", 10, 70, 20);
                break;
            case "bossbar":
                BossBar bossBar = Bukkit.createBossBar(message, BarColor.RED, BarStyle.SOLID);
                bossBar.addPlayer(targetPlayer);
                Bukkit.getScheduler().runTaskLater(plugin, bossBar::removeAll, 100); // Czas trwania BossBar (w tikach, 20 tików = 1 sekunda)
                break;
            case "actionbar":
                targetPlayer.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(message));
                break;
            default:
                targetPlayer.sendMessage("Nieznana metoda wyświetlania. Dostępne metody to: title, bossbar, actionbar.");
                break;
        }
    }
}

