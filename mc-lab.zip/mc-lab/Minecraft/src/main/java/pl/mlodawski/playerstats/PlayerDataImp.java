package pl.mlodawski.playerstats;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;
import java.util.stream.Collectors;

public class PlayerDataImp {
    private List<PlayerData> getAllPlayersData() {
        return Bukkit.getOnlinePlayers().stream()
                .map(player -> {
                    String playerName = player.getName();
                    String playerDisplayName = player.getDisplayName();
                    String playerUUID = player.getUniqueId().toString();
                    double health = player.getHealth();
                    int foodLevel = player.getFoodLevel();
                    Location location = player.getLocation();
                    int x = location.getBlockX();
                    int y = location.getBlockY();
                    int z = location.getBlockZ();
                    int[] locationArray = {x, y, z};
                    return new PlayerData(playerName, playerDisplayName, playerUUID, health, foodLevel, locationArray);
                })
                .collect(Collectors.toList());
    }

    public void startTask(Plugin plugin) {
        new BukkitRunnable() {
            @Override
            public void run() {
                List<PlayerData> playersData = getAllPlayersData();
                try {
                    ObjectMapper objectMapper = new ObjectMapper();
                    String jsonPlayersData = objectMapper.writeValueAsString(playersData);

                    HttpClient client = HttpClient.newHttpClient();
                    HttpRequest request = HttpRequest.newBuilder()
                            .header("Content-Type", "application/json")
                            .uri(URI.create("http://localhost:8080/players"))
                            .POST(HttpRequest.BodyPublishers.ofString(jsonPlayersData))
                            .build();

                    HttpResponse<String> response = client.send(request,
                            HttpResponse.BodyHandlers.ofString());

                    plugin.getLogger().info(response.body());
                    plugin.getLogger().info("Dane wszystkich graczy w formacie JSON: " + jsonPlayersData);
                } catch (Exception e) {
                    plugin.getLogger().warning(e + "\n" + e.getStackTrace().toString());
                }
            }
        }.runTaskTimer(plugin, 0, 200); // 10 seconds (10 * 20 ticks per second)
    }
}
