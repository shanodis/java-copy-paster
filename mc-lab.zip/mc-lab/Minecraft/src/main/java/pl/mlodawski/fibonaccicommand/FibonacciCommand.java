package pl.mlodawski.fibonaccicommand;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;
import java.util.Arrays;
public class FibonacciCommand implements CommandExecutor {

    private final Plugin plugin;
    private final FibonacciCommandImp fibonacciCommandImp;

    /**
     * Konstruktor FibonacciCommand związany z określonym wtyczką.
     *
     * @param plugin wtyczka powiązana z pluginem
     */
    public FibonacciCommand(Plugin plugin) {
        this.plugin = plugin;
        this.fibonacciCommandImp = new FibonacciCommandImp(plugin);
    }

    /**
     * Wykonuje polecenie Fibonacci.
     *
     * @param sender  nadawca polecenia
     * @param command wykonane polecenie
     * @param label   etykieta polecenia
     * @param args    argumenty polecenia
     * @return true, jeśli polecenie zostało pomyślnie wykonane, false w przeciwnym razie
     */
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1) {
            fibonacciCommandImp.execute(sender, Arrays.stream(args).toArray());
        } else {
            sender.sendMessage("Użycie: /fib <n>");
        }
        return true;
    }
}
