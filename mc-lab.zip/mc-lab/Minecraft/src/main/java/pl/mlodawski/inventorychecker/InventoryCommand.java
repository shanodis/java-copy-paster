package pl.mlodawski.inventorychecker;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;
import java.util.Arrays;

public class InventoryCommand implements CommandExecutor {
    private final Plugin plugin;
    private final InventoryCommandImp inventoryCommandImp;

    public InventoryCommand(Plugin plugin) {
        this.plugin = plugin;
        this.inventoryCommandImp = new InventoryCommandImp(plugin);
    }

    /**
     Wykonuje polecenie komendy "inventory".
     @param sender obiekt wysyłający polecenie
     @param command komenda
     @param label etykieta komendy
     @param args argumenty komendy
     @return true, jeśli polecenie zostało pomyślnie wykonane, false w przeciwnym razie
     */
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1) {
            inventoryCommandImp.execute(sender, Arrays.stream(args).toArray());
        } else {
            sender.sendMessage("Użycie: /ekwipunek <gracz>");
        }
        return true;
    }
}
