package pl.mlodawski.motdcommand;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;

import java.util.Arrays;

public class MOTDCommand implements CommandExecutor {

    private final MOTDCommandImp motdCommandImp;

    public MOTDCommand(Plugin plugin) {
        this.motdCommandImp = new MOTDCommandImp(plugin);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length >= 3) {
            String displayMethod = args[0];
            String target = args[1];
            String message = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
            motdCommandImp.execute(sender, displayMethod, target, message);
        } else {
            sender.sendMessage("Użycie: /motd <metoda> <gracz/all> <wiadomość>");
        }
        return true;
    }
}
