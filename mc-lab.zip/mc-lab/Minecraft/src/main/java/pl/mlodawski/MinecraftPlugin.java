package pl.mlodawski;

import org.bukkit.plugin.java.JavaPlugin;
import pl.mlodawski.chatlistener.ChatListener;
import pl.mlodawski.fibonaccicommand.FibonacciCommand;
import pl.mlodawski.inventorychecker.InventoryCommand;
import pl.mlodawski.motdcommand.MOTDCommand;
import pl.mlodawski.playerstats.PlayerDataImp;
import pl.mlodawski.summonlightning.SummonLightningCommand;

import java.util.Objects;


public class MinecraftPlugin extends JavaPlugin {
    @Override
    public void onEnable() {
        getLogger().info("Minecraft plugin został włączony!");
        getServer().getPluginManager().registerEvents(new ChatListener(this), this);

        Objects.requireNonNull(this.getCommand("ekwipunek")).setExecutor(new InventoryCommand(this));
        Objects.requireNonNull(this.getCommand("blyskawica")).setExecutor(new SummonLightningCommand(this));
        Objects.requireNonNull(this.getCommand("fib")).setExecutor(new FibonacciCommand(this));
        Objects.requireNonNull(this.getCommand("motd")).setExecutor(new MOTDCommand(this));

        new PlayerDataImp().startTask(this);
    }

    @Override
    public void onDisable() {
        getLogger().info("Minecraft plugin został wyłączony.");
    }
}
