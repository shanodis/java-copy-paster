package pl.mlodawski.inventorychecker;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.bukkit.inventory.meta.ItemMeta;

public abstract class ItemStackMixin {

    @JsonIgnore
    abstract ItemMeta getItemMeta();
}