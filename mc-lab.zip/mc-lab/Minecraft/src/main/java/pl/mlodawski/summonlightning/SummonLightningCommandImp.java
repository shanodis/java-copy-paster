package pl.mlodawski.summonlightning;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;



public class SummonLightningCommandImp{

    private final Plugin plugin;

    public SummonLightningCommandImp(Plugin plugin) {
        this.plugin = plugin;
    }


    public void execute(CommandSender sender,Object... args) {
        if (args.length == 3) {
            try {
                int x = Integer.parseInt(args[0].toString());
                int y = Integer.parseInt(args[1].toString());
                int z = Integer.parseInt(args[2].toString());

                Bukkit.getScheduler().runTask(plugin, () -> {
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                            "execute positioned " + x + " " + y + " " + z + " run summon lightning_bolt");
                });
                sender.sendMessage("Błyskawica została przywołana na pozycji: " + x + " " + y + " " + z);
            } catch (NumberFormatException e) {
                sender.sendMessage("Wprowadzone współrzędne muszą być liczbami całkowitymi.");
            }
        } else {
            sender.sendMessage("Niepoprawna liczba argumentów.");
        }
    }
}
