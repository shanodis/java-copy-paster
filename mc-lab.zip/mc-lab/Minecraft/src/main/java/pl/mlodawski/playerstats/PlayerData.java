package pl.mlodawski.playerstats;

public class PlayerData {
    private String playerName;
    private String playerDisplayName;
    private String playerUUID;
    private double health;
    private int foodLevel;
    private int[] location;

    public PlayerData(String playerName, String playerDisplayName, String playerUUID, double health, int foodLevel, int[] location) {
        this.playerName = playerName;
        this.playerDisplayName = playerDisplayName;
        this.playerUUID = playerUUID;
        this.health = health;
        this.foodLevel = foodLevel;
        this.location = location;
    }

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public String getPlayerDisplayName() {
        return playerDisplayName;
    }

    public void setPlayerDisplayName(String playerDisplayName) {
        this.playerDisplayName = playerDisplayName;
    }

    public String getPlayerUUID() {
        return playerUUID;
    }

    public void setPlayerUUID(String playerUUID) {
        this.playerUUID = playerUUID;
    }

    public int[] getLocation() {
        return location;
    }

    public void setLocation(int[] location) {
        this.location = location;
    }

    public double getHealth() {
        return health;
    }

    public void setHealth(double health) {
        this.health = health;
    }

    public int getFoodLevel() {
        return foodLevel;
    }

    public void setFoodLevel(int foodLevel) {
        this.foodLevel = foodLevel;
    }
}
