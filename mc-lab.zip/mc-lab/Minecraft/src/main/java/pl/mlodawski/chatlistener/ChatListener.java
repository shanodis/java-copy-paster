package pl.mlodawski.chatlistener;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.plugin.Plugin;
import pl.mlodawski.fibonaccicommand.FruitsLoader;
import pl.mlodawski.summonlightning.SummonLightningCommandImp;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static org.bukkit.Bukkit.getLogger;

public class ChatListener implements Listener {


    private final FruitsLoader fruitsLoader = new FruitsLoader();

    private List<String> fruits = new ArrayList<>();

    private final Plugin plugin;
    private final SummonLightningCommandImp summonLightningCommandImp;

    /**
     Konstruktor ChatListener związany z określoną wtyczką.
     @param plugin wtyczka powiązana ze pluginem
     */
    public ChatListener(Plugin plugin) {
        this.plugin = plugin;
        this.summonLightningCommandImp = new SummonLightningCommandImp(plugin);
        File serverFolder = plugin.getDataFolder().getParentFile();
        File fruitsFile = new File(serverFolder, "fruits.json");
        fruits = fruitsLoader.loadFruitsFromJson(fruitsFile);
    }

    Long numberOfMessage = 0L;

    /**
     Obsługuje zdarzenie czatu serwera.
     @param event zdarzenie czatu serwera
     */
    @EventHandler
    public void onPlayerChat(AsyncPlayerChatEvent event) {

        // Pobiera informacje o graczu i wiadomości
        final Player player = event.getPlayer();
        final String playerName = player.getName();
        final String playerDisplayName = player.getDisplayName();
        final String playerUUID = player.getUniqueId().toString();
        final String message = event.getMessage();

        // Pobiera informacje o lokalizacji gracza
        final Location location = player.getLocation();
        final int x = location.getBlockX();
        final int y = location.getBlockY();
        final int z = location.getBlockZ();

        final String playerIP = Objects.requireNonNull(player.getAddress()).getAddress().getHostAddress();
        final String playerLocale = player.getLocale();

        String playerMessage = event.getMessage();
        getLogger().info("<" + numberOfMessage + ">" + "[" + playerName + "]: " + playerMessage);

        getLogger().info("Wiadomość od gracza:");
        getLogger().info(" - Nazwa: " + playerName);
        getLogger().info(" - Wyświetlana nazwa: " + playerDisplayName);
        getLogger().info(" - UUID: " + playerUUID);
        getLogger().info(" - Wiadomość: " + message);
        getLogger().info(" - Lokacja: "  + " [" + x + ", " + y + ", " + z + "]");
        getLogger().info(" - Adres IP: " + playerIP);
        getLogger().info(" - Język: " + playerLocale);
        numberOfMessage++;

        // Sprawdza, czy wiadomość gracza zawiera jakieś owoce i wykonaj odpowiednią akcję
        for (String fruit :fruits) {
            if (message.toLowerCase().contains(fruit.toLowerCase())) {
                summonLightningCommandImp.execute( player, x, y, z);
                break;
            }
        }
    }
}
