package pl.mlodawski.summonlightning;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;


import java.util.Arrays;

public class SummonLightningCommand implements CommandExecutor {


    private final Plugin plugin;
    private final SummonLightningCommandImp summonLightningCommandImp;

    public SummonLightningCommand(Plugin plugin) {
        this.plugin = plugin;
        this.summonLightningCommandImp = new SummonLightningCommandImp(plugin);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 3) {
            summonLightningCommandImp.execute(sender, Arrays.stream(args).toArray());
        } else {
            sender.sendMessage("Użycie: /blyskawica <x> <y> <z>");
        }
        return true;
    }
}
