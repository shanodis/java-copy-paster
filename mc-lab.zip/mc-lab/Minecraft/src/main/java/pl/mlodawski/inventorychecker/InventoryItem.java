package pl.mlodawski.inventorychecker;

public class InventoryItem {
    private final String type;
    private final int amount;
    private final int position;

    public InventoryItem(String type, int amount, int position) {
        this.type = type;
        this.amount = amount;
        this.position = position;
    }

    public String getType() {
        return type;
    }

    public int getAmount() {
        return amount;
    }

    public int getPosition() {
        return position;
    }
}