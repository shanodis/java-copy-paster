package pl.mlodawski.inventorychecker;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.List;

import static org.bukkit.Bukkit.getLogger;

public class InventoryCommandImp {
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final Plugin plugin;

    public InventoryCommandImp(Plugin plugin) {
        this.plugin = plugin;
        objectMapper.addMixIn(ItemStack.class, ItemStackMixin.class);
    }

    /**
     Wykonuje polecenie "inventory".
     @param sender obiekt wysyłający polecenie
     @param args argumenty polecenia
     */
    public void execute(CommandSender sender, Object... args) {
        // Sprawdza, czy CommandSender jest graczem
        if (sender instanceof Player OPplayer) {
            //Sprawdza, czy gracz posiada określone uprawnienia
            if (OPplayer.hasPermission("inventory.check")) {
                if (args.length == 1) {
                    final Player player = Bukkit.getPlayer(args[0].toString());
                    if (player == null) {
                        getLogger().warning("Nie znaleziono gracza o podanej nazwie.");
                        return;
                    }
                    try {
                        objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
                        ItemStack[] inventoryContents = player.getInventory().getContents();

                        List<InventoryItem> inventoryItems = new ArrayList<>();
                        for (int i = 0; i < inventoryContents.length; i++) {
                            ItemStack itemStack = inventoryContents[i];
                            if (itemStack != null) {
                                inventoryItems.add(new InventoryItem(itemStack.getType().toString(), itemStack.getAmount(), i));
                            }
                        }

                        String json = objectMapper.writeValueAsString(inventoryItems);
                        getLogger().info("Ekwipunek gracza " + player.getName() + " jako JSON: " + json);
                    } catch (Exception e) {
                        getLogger().warning("Nie udało się przekształcić ekwipunku na JSON: " + e.getMessage());
                    }
                } else {
                    OPplayer.sendMessage("Niepoprawna liczba argumentów.");
                }
            } else {
                OPplayer.sendMessage("Nie masz uprawnień do korzystania z tej komendy.");
            }
        }
    }
}

