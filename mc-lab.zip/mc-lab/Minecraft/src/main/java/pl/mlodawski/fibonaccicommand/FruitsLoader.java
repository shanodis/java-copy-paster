package pl.mlodawski.fibonaccicommand;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

import static org.bukkit.Bukkit.getLogger;

public class FruitsLoader {
    private final  ObjectMapper objectMapper = new ObjectMapper();

    /**
     Wczytuje owoce z pliku JSON.
     @param file plik JSON zawierający listę owoców
     @return lista wczytanych owoców, lub pusta lista w przypadku błędu lub braku pliku
     */
    public List<String> loadFruitsFromJson(File file) {
        try {
            if (file.exists()) {
                return objectMapper.readValue(file, new TypeReference<List<String>>() {});
            } else {
                getLogger().warning("Plik nie istnieje: " + file.getAbsolutePath());
                return Collections.emptyList(); // Zwraca pustą listę w przypadku braku pliku
            }
        } catch (IOException e) {
            getLogger().warning("Błąd wczytywania pliku JSON: " + e.getMessage());
            return Collections.emptyList(); // Zwraca pustą listę w przypadku błędu wczytywania pliku
        }
    }
}
