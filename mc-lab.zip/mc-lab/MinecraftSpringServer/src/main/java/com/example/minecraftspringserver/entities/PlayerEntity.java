package com.example.minecraftspringserver.entities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "player")
@Getter
@Setter
@NoArgsConstructor
public class PlayerEntity {
    @Id
    @Column(nullable = false, updatable = false)
    private String playerUUID;

    private String playerName;
    private String playerDisplayName;
    private double health;
    private int foodLevel;
    private String location;
}
