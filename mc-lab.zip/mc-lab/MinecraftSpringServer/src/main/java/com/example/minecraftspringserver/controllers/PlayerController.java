package com.example.minecraftspringserver.controllers;

import com.example.minecraftspringserver.dtos.PlayerRequestDTO;
import com.example.minecraftspringserver.entities.PlayerEntity;
import com.example.minecraftspringserver.services.PlayerService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("players")
@AllArgsConstructor
public class PlayerController {
    private final PlayerService playerService;

    @PostMapping
    public ResponseEntity<String> addPlayer(@RequestBody List<PlayerRequestDTO> playerRequestDTO) {
        return playerService.addPlayer(playerRequestDTO);
    }

    @GetMapping
    public String getPlayers(Model model) {
        List<PlayerEntity> playerList = playerService.getPlayers();
        model.addAttribute("playerList", playerList);
        return "players";
    }
}
