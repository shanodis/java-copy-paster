package com.example.minecraftspringserver.dtos;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

@AllArgsConstructor
@Getter
public class PlayerRequestDTO {
    private String playerUUID;
    private String playerName;
    private String playerDisplayName;
    private double health;
    private int foodLevel;
    private int[] location;

    @Override
    public String toString() {
        return "\nplayerUUID: " + playerUUID + "\n" +
                "playerName: " + playerName + "\n" +
                "playerDisplayName: " + playerDisplayName + "\n" +
                "health: " + health + "\n" +
                "foodLevel: " + foodLevel + "\n" +
                "location: " + Arrays.toString(location) + "\n";
    }
}
