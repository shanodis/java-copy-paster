package com.example.minecraftspringserver.services;

import com.example.minecraftspringserver.dtos.PlayerRequestDTO;
import com.example.minecraftspringserver.entities.PlayerEntity;
import com.example.minecraftspringserver.repositories.PlayerRepository;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class PlayerService {
    private final PlayerRepository playerRepository;
    private final Logger logger = LoggerFactory.getLogger(PlayerService.class);

    public List<PlayerEntity> getPlayers() {
        return playerRepository.findAll();
    }

    public ResponseEntity<String> addPlayer(List<PlayerRequestDTO> players) {
        if (players.isEmpty()) {
            return new ResponseEntity<>("Nothing to update", HttpStatus.BAD_REQUEST);
        }

        logger.info("Received from plugin: " + players);

        List<PlayerEntity> newPlayers = players
                .stream()
                .filter((player) -> !playerRepository.existsByPlayerUUID(player.getPlayerUUID()))
                .map((newPlayer) -> {
                    int[] cords = newPlayer.getLocation();
                    String[] cordLabels = { "X", "Y", "Z" };
                    StringBuilder stringBuilder = new StringBuilder();

                    for (int i = 0; i < cords.length; i++) {
                        stringBuilder.append(String.format("%s: %d ", cordLabels[i], cords[i]));
                    }

                    String location = stringBuilder.toString().trim();

                    PlayerEntity playerEntity = new PlayerEntity();
                    playerEntity.setPlayerUUID(newPlayer.getPlayerUUID());
                    playerEntity.setPlayerName(newPlayer.getPlayerName());
                    playerEntity.setPlayerDisplayName(newPlayer.getPlayerDisplayName());
                    playerEntity.setHealth(newPlayer.getHealth());
                    playerEntity.setFoodLevel(newPlayer.getFoodLevel());
                    playerEntity.setLocation(location);

                    return playerEntity;
                })
                .collect(Collectors.toList());

        playerRepository.saveAll(newPlayers);

        return new ResponseEntity<>("New player has been added successfully", HttpStatus.OK);
    }
}
