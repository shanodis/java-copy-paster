package com.example.minecraftspringserver.repositories;

import com.example.minecraftspringserver.entities.PlayerEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface PlayerRepository extends JpaRepository<PlayerEntity, UUID> {
    boolean existsByPlayerUUID(String playerUUID);
}
