package com.dg_mw.controllers;

import com.dg_mw.dtos.CalculatorOperationResponse;
import com.dg_mw.services.CalculatorOperationService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Validated
@RestController
@AllArgsConstructor
@RequestMapping("calculator-operations")
public class CalculatorOperationController {
    private CalculatorOperationService calculatorOperationsService;

    @GetMapping("/add")
    public CalculatorOperationResponse add(
            @Valid
            @NotNull
            @Size(min = 2, message = "Provide at least two numbers")
            @RequestParam(name = "numbers")
            List<Float> numbers
    ) {
        return this.calculatorOperationsService.add(numbers);
    }

    @GetMapping("/subtract")
    public CalculatorOperationResponse subtract(
            @Valid
            @NotNull
            @Size(min = 2, message = "Provide at least two numbers")
            @RequestParam(name = "numbers")
            List<Float> numbers
    ) {
        return this.calculatorOperationsService.subtract(numbers);
    }

    @GetMapping("/multiply")
    public CalculatorOperationResponse multiply(
            @Valid
            @NotNull
            @Size(min = 2, message = "Provide at least two numbers")
            @RequestParam(name = "numbers")
            List<Float> numbers
    ) {
        return this.calculatorOperationsService.multiply(numbers);
    }

    @GetMapping("/divide")
    public CalculatorOperationResponse divide(
            @Valid
            @NotNull
            @Size(min = 2, message = "Provide at least two numbers")
            @RequestParam(name = "numbers")
            List<Float> numbers
    ) {
        return this.calculatorOperationsService.divide(numbers);
    }
}
