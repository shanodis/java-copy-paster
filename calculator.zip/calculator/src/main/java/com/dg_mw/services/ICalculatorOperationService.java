package com.dg_mw.services;

import com.dg_mw.dtos.CalculatorOperationResponse;

import java.util.List;

public interface ICalculatorOperationService {
    CalculatorOperationResponse add(List<Float> numbers);
    CalculatorOperationResponse subtract(List<Float> numbers);
    CalculatorOperationResponse multiply(List<Float> numbers);
    CalculatorOperationResponse divide(List<Float> numbers);
}
