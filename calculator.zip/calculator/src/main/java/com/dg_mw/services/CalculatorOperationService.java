package com.dg_mw.services;

import com.dg_mw.dtos.CalculatorOperationResponse;
import lombok.AllArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
@AllArgsConstructor
public class CalculatorOperationService implements ICalculatorOperationService {
    private final Logger logger = LogManager.getLogger(CalculatorOperationService.class);
    @Override
    public CalculatorOperationResponse add(List<Float> numbers) {
        logger.info("Called method add");
        Float result = numbers.stream().reduce(0f, Float::sum);
        return new CalculatorOperationResponse(result);
    }

    @Override
    public CalculatorOperationResponse subtract(List<Float> numbers) {
        logger.info("Called method subtract");
        Float identity = numbers.remove(0);
        Float result = numbers.stream().reduce(identity, (partialSum, number) -> partialSum - number);
        return new CalculatorOperationResponse(result);
    }

    @Override
    public CalculatorOperationResponse multiply(List<Float> numbers) {
        logger.info("Called method multiply");
        Float result = numbers.stream().reduce(1f, (partialSum, number) -> partialSum * number);
        return new CalculatorOperationResponse(result);
    }

    @Override
    public CalculatorOperationResponse divide(List<Float> numbers) {
        logger.info("Called method divide");
        if (numbers.stream().anyMatch(number -> number == 0f)) {
            logger.error("Divided by 0");
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Can't divide by 0!");
        }
        Float identity = numbers.remove(0);
        Float result = numbers.stream().reduce(identity, (partialSum, number) -> partialSum / number);
        return new CalculatorOperationResponse(result);
    }
}
