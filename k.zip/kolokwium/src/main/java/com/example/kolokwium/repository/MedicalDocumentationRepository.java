package com.example.kolokwium.repository;

import com.example.kolokwium.models.MedicalDocumentationModel;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public class MedicalDocumentationRepository {
    private final List<MedicalDocumentationModel> documentationList = new ArrayList<>();

    public MedicalDocumentationModel save(MedicalDocumentationModel model) {
        documentationList.add(model);
        return model;
    }

    public List<MedicalDocumentationModel> findAll() {
        return documentationList;
    }

    public Optional<MedicalDocumentationModel> findById(UUID id) {
        return documentationList
                .stream()
                .filter(item -> item.getMedicalDocumentationId().equals(id))
                .findAny();
    }

    public boolean remove(UUID id) {
        return documentationList.removeIf(item -> item.getMedicalDocumentationId().equals(id));
    }
}
