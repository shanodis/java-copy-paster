package com.example.kolokwium.service;

import com.example.kolokwium.models.DiagnosticRequest;
import com.example.kolokwium.models.MedicalDocumentationModel;
import com.example.kolokwium.models.MedicalDocumentationRequest;
import com.example.kolokwium.repository.MedicalDocumentationRepository;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@AllArgsConstructor
public class MedicalDocumentationService {
    private final MedicalDocumentationRepository documentationRepository;

    public ResponseEntity<String> addMedicalDocumentation(MedicalDocumentationRequest documentationRequest) {
        MedicalDocumentationModel entity = new MedicalDocumentationModel();
        entity.setCreatedOn(new Date());
        entity.setEditedOn(new Date());
        entity.setDescription(documentationRequest.getDescription());
        entity.setDiagnostic(documentationRequest.getDiagnostic());
        entity.setPatientName(documentationRequest.getPatientName());
        entity.setHealth(documentationRequest.getHealth());
        entity.setMedicalDocumentationId(UUID.randomUUID());

        MedicalDocumentationModel savedEntity = documentationRepository.save(entity);

        return ResponseEntity.ok("Medical documentation saved Id:" + savedEntity.getMedicalDocumentationId());
    }

    public List<MedicalDocumentationModel> getAllMedicalDocumentations() {
        return documentationRepository.findAll();
    }

    public ResponseEntity<String> updateDiagnostic(UUID medicalDocumentationId,DiagnosticRequest diagnosticRequest) {
        Optional<MedicalDocumentationModel> entity = documentationRepository.findById(medicalDocumentationId);

        if (entity.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        MedicalDocumentationModel foundEntity = entity.get();

        foundEntity.setDiagnostic(diagnosticRequest.getDiagnostic());
        foundEntity.setEditedOn(new Date());

        return ResponseEntity.ok("Medical documentation edited Id:" + foundEntity.getMedicalDocumentationId());
    }

    public ResponseEntity<String> deleteMedicalDocumentation(UUID medicalDocumentationId) {
        Optional<MedicalDocumentationModel> entity = documentationRepository.findById(medicalDocumentationId);

        if (entity.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        MedicalDocumentationModel foundEntity = entity.get();

        documentationRepository.remove(foundEntity.getMedicalDocumentationId());

        return ResponseEntity.ok("Medical documentation deleted Id:" + foundEntity.getMedicalDocumentationId());
    }
}
