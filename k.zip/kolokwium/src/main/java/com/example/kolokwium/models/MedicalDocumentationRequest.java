package com.example.kolokwium.models;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

@Data
public class MedicalDocumentationRequest {
    @NotBlank
    @Length(max = 25)
    public String patientName;

    @Length(max = 10)
    public String diagnostic;

    @NotBlank
    @Size(min = 1, max = 5)
    public Integer health;

    @NotBlank
    @Length(max = 500)
    public String description;
}
