package com.example.kolokwium.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Arrays;

public class CookieFilter extends OncePerRequestFilter {
    private static final String REQUIRED_COOKIE_NAME = "JSESSIONID";

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        Cookie[] cookies = request.getCookies();
        boolean cookieFound = false;

        if (cookies != null) {
            cookieFound = Arrays.stream(cookies).anyMatch(cookie -> REQUIRED_COOKIE_NAME.equals(cookie.getName()));
        }

        if (cookieFound) {
            filterChain.doFilter(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Required cookie not found");
        }
    }
}
