package com.example.kolokwium.controller;

import com.example.kolokwium.models.DiagnosticRequest;
import com.example.kolokwium.models.MedicalDocumentationModel;
import com.example.kolokwium.models.MedicalDocumentationRequest;
import com.example.kolokwium.service.MedicalDocumentationService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@Controller
@AllArgsConstructor
public class MedicalDocumentationController {
    private final MedicalDocumentationService service;

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        List<MedicalDocumentationModel> documentations = service.getAllMedicalDocumentations();
        model.addAttribute("documentations", documentations);
        model.addAttribute("diagnosticRequest", new DiagnosticRequest());
        return "dashboard";
    }

    @GetMapping("/medical-documentation/new")
    public String addMedicalDocumentation(Model model) {
        model.addAttribute("medicalDocumentation", new MedicalDocumentationRequest());
        return "add-medical-documentation";
    }

    @PostMapping("/api/medical-documentation")
    public String addMedicalDocumentation(@ModelAttribute MedicalDocumentationRequest request) {
        service.addMedicalDocumentation(request);
        return "redirect:/dashboard";
    }

    @PutMapping("/api/medical-documentation/{medicalDocumentationId}")
    public ResponseEntity<String> editMedicalDocumentation(@PathVariable UUID medicalDocumentationId, @RequestBody DiagnosticRequest request) {
        return service.updateDiagnostic(medicalDocumentationId, request);
    }

    @DeleteMapping("/api/medical-documentation/{medicalDocumentationId}")
    public ResponseEntity<String> deleteMedicalDocumentation(@PathVariable UUID medicalDocumentationId) {
        return service.deleteMedicalDocumentation(medicalDocumentationId);
    }
}
