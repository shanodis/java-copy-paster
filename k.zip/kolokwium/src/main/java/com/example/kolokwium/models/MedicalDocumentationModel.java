package com.example.kolokwium.models;

import lombok.Data;

import java.util.Date;
import java.util.UUID;

@Data
public class MedicalDocumentationModel {
    private UUID medicalDocumentationId;
    private String patientName;
    private String diagnostic;
    private Integer health;
    private String description;
    private Date createdOn;
    private Date editedOn;
}
