package com.example.kolokwium.models;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

@Data
public class DiagnosticRequest {
    @NotBlank
    @Length(max = 10)
    public String diagnostic;
}
