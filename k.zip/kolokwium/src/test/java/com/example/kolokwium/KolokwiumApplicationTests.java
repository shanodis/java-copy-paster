package com.example.kolokwium;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KolokwiumApplicationTests {

	@Test
	void contextLoads() {
	}

}
